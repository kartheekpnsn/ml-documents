df = data.frame(a = runif(1000), b = runif(1000))
df$Y = 2*df$a + 3*df$b

test = data.frame(a = runif(10), b = runif(10))
test$Y = 2 * test$a + 3 * test$b

# # without pca
fit = lm(Y ~ ., data = df)
error_measure(test$Y, predict(fit, test))

# # with pca
pca = prcomp(df[, c('a', 'b')], scale = T, center = T)
ncomp = 2
rawLoadings = pca$rotation[, 1:ncomp] %*% diag(pca$sdev, ncomp, ncomp)
rotatedLoadings = varimax(rawLoadings)$loadings
library(pracma)
invLoadings = t(pracma::pinv(rotatedLoadings))
scores = scale(df[, c('a','b')]) %*% invLoadings

pc = data.frame(cbind(scores, Y = df[,"Y"]))

pca_fit = lm(Y ~ ., data = pc)
summary(pca_fit)  ### Now R2 is 1,Vif(fit) returns 1 for all components


error_measure(test$Y, predict(pca_fit, test))

library(car)
print(vif(pca_fit))
print(cor(pc))