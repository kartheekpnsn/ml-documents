nMovies = 1000
nUsers = 100

set.seed(294056)

ratings = matrix(numeric(nMovies * nUsers), nrow = nUsers)

for(i in 1:nMovies) {
	for(j in 1:nUsers) {
		flag = as.numeric((runif(1)) * 0.7 >= 0.5)
		if(flag == 1) {
			ratings[j, i] = round(runif(1, 1, 5))
		}
	}
}

source("https://raw.githubusercontent.com/kartheekpnsn/machine-learning-codes/master/R/functions.R")

distances = matrix(numeric(nUsers * nUsers), nrow = nUsers)
for(i in 1:nUsers) {
	for(j in 1:nUsers) {
		distances[i, j] = similarityMeasure(ratings[i, ], ratings[j, ])
	}
}

distances2 = matrix(numeric(nMovies * nMovies), nrow = nMovies)
for(i in 1:nMovies) {
	for(j in 1:nMovies) {
		distances2[i, j] = similarityMeasure(ratings[, i], ratings[, j])
	}
}

