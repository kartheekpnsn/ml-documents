
setwd("E:\\MyViewsOperationalAnalytics\\MyTables")
sink("Logs.txt");
cat(paste("\n Started the Execution at",Sys.time()));
library(RODBC)
odbc = odbcDriverConnect(connection="server=MYVIEWSOA01;database=Subrogation;trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;")       
Claim=sqlQuery(odbc, "SELECT * FROM V_ClaimTable");
Policy=sqlQuery(odbc, "SELECT * FROM V_PolicyTable");
Repair=sqlQuery(odbc, "SELECT * FROM V_RepairTable");
Risk=sqlQuery(odbc, "SELECT * FROM V_RiskTable");
Vehicle=sqlQuery(odbc, "SELECT * FROM V_VehicleTable");
Party=sqlQuery(odbc, "SELECT * FROM V_PartyTable");

###########################################################################################
######################################DATA PROCESSING : Recoding and Transposing###########
cat(paste("\n Started the Transposing at",Sys.time()));
####################VEHICLE TABLE#######################
Vehicle_L5=Vehicle
## Recoding of Vehicle make
rm(Vehicle)
# Changing vehicle make alphabets to lower case
Vehicle_L5$VEHICLEMAKE<-tolower(Vehicle_L5$VEHICLEMAKE)

Vehicle_L5$VEHICLEMAKE_Recoded[grep("",Vehicle_L5$VEHICLEMAKE)]<-"others"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("alfa",Vehicle_L5$VEHICLEMAKE)]<-"Alfa Romeo"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("ambulance",Vehicle_L5$VEHICLEMAKE)]<-"Ambulance"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("audi",Vehicle_L5$VEHICLEMAKE)]<-"Audi"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("bmw",Vehicle_L5$VEHICLEMAKE)]<-"BMW"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("ford",Vehicle_L5$VEHICLEMAKE)]<-"Ford"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("holden",Vehicle_L5$VEHICLEMAKE)]<-"Holden"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("honda",Vehicle_L5$VEHICLEMAKE)]<-"Honda"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("hyund",Vehicle_L5$VEHICLEMAKE)]<-"Hyundai"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("jeep",Vehicle_L5$VEHICLEMAKE)]<-"Jeep"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("kia",Vehicle_L5$VEHICLEMAKE)]<-"Kia"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("land",Vehicle_L5$VEHICLEMAKE)]<-"Landrover"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("lexus",Vehicle_L5$VEHICLEMAKE)]<-"Lexus"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("mazda",Vehicle_L5$VEHICLEMAKE)]<-"Mazda"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("merc",Vehicle_L5$VEHICLEMAKE)]<-"Mercedes"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("mitsu",Vehicle_L5$VEHICLEMAKE)]<-"Mitsubishi"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("nissan",Vehicle_L5$VEHICLEMAKE)]<-"Nissan"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("peugeot",Vehicle_L5$VEHICLEMAKE)]<-"Peugeot"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("renault",Vehicle_L5$VEHICLEMAKE)]<-"Renault"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("subaru",Vehicle_L5$VEHICLEMAKE)]<-"Subaru"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("suzuki",Vehicle_L5$VEHICLEMAKE)]<-"Suzuki"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("toy",Vehicle_L5$VEHICLEMAKE)]<-"Toyota"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("truck",Vehicle_L5$VEHICLEMAKE)]<-"Truck"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("unknown",Vehicle_L5$VEHICLEMAKE)]<-"Unknown"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("volks",Vehicle_L5$VEHICLEMAKE)]<-"Volkswagen"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("volv",Vehicle_L5$VEHICLEMAKE)]<-"Volvo"
Vehicle_L5$VEHICLEMAKE_Recoded[grep("york",Vehicle_L5$VEHICLEMAKE)]<-"York"

#write.csv(Vehicle_L5,"Motor Vehicle/Output/AB/Vehicle_L5_Rec.csv",row.names=FALSE)

## Age of vehicle
Vehicle_L5$VEHICLEAGE <- ifelse(is.na(Vehicle_L5$VEHICLEYEAR) | Vehicle_L5$VEHICLEYEAR=="", 0, 2015 - Vehicle_L5$VEHICLEYEAR)

##Categorical to numeric recoding for: Vehicle Damage and Vehicle Total loss
Vehicle_L5$VEHICLEDAMAGE_Recoded[Vehicle_L5$VEHICLEDAMAGE == "Yes"] <- 1
Vehicle_L5$VEHICLEDAMAGE_Recoded[Vehicle_L5$VEHICLEDAMAGE == "No"] <- 0

Vehicle_L5$VEHICLETOTALLOSS_Recoded[Vehicle_L5$VEHICLETOTALLOSS== "Yes"] <- 1
Vehicle_L5$VEHICLETOTALLOSS_Recoded[Vehicle_L5$VEHICLETOTALLOSS== "No"] <- 0

##Transposing required for: Vehiclemake_recoded, Vehicle age, Driverage, Vehicle Loss party
##Vehiclestyle, partytp
##Aggregation required for Vehicledamage_recoded, Vehicletotalloss_recoded

##Arranging the claimid's in descending order
Vehicle_L5 <- Vehicle_L5[order(Vehicle_L5$CLAIMID),]

library(gtools)

#Splitting files into
Vehicle_L61 <- Vehicle_L5[c(1:100000),]
Vehicle_L62 <- Vehicle_L5[c(100001:200000),]
Vehicle_L63 <- Vehicle_L5[c(200001:300000),]
Vehicle_L64 <- Vehicle_L5[c(300001:400000),]
Vehicle_L65 <- Vehicle_L5[c(400001:500000),]
Vehicle_L66 <- Vehicle_L5[c(500001:600000),]
Vehicle_L67 <- Vehicle_L5[c(600001:704780),]
rm(Vehicle_L5)
library(reshape)

##1.Vehiclemake
make1 <- data.frame(temp=1, CLAIMID=Vehicle_L61$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L61$VEHICLEMAKE_Recoded)
melt1 <- melt(make1, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE1 <- cast(melt1, CLAIMID~VEHICLEMAKE_Recoded)

make2 <- data.frame(temp=1, CLAIMID=Vehicle_L62$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L62$VEHICLEMAKE_Recoded)
melt2 <- melt(make2, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE2 <- cast(melt2, CLAIMID~VEHICLEMAKE_Recoded)

make3 <- data.frame(temp=1, CLAIMID=Vehicle_L63$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L63$VEHICLEMAKE_Recoded)
melt3 <- melt(make3, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE3 <- cast(melt3, CLAIMID~VEHICLEMAKE_Recoded)

make4 <- data.frame(temp=1, CLAIMID=Vehicle_L64$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L64$VEHICLEMAKE_Recoded)
melt4 <- melt(make4, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE4 <- cast(melt4, CLAIMID~VEHICLEMAKE_Recoded)

make5 <- data.frame(temp=1, CLAIMID=Vehicle_L65$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L65$VEHICLEMAKE_Recoded)
melt5 <- melt(make5, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE5 <- cast(melt5, CLAIMID~VEHICLEMAKE_Recoded)

make6 <- data.frame(temp=1, CLAIMID=Vehicle_L66$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L66$VEHICLEMAKE_Recoded)
melt6 <- melt(make6, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE6 <- cast(melt6, CLAIMID~VEHICLEMAKE_Recoded)

make7 <- data.frame(temp=1, CLAIMID=Vehicle_L67$CLAIMID, VEHICLEMAKE_Recoded=Vehicle_L67$VEHICLEMAKE_Recoded)
melt7 <- melt(make7, id=c("CLAIMID", "VEHICLEMAKE_Recoded"))
MAKE7 <- cast(melt7, CLAIMID~VEHICLEMAKE_Recoded)

MAKE <- smartbind(MAKE1,MAKE2,MAKE3,MAKE4,MAKE5,MAKE6,MAKE7)

rm(make1,make2,make3,make4,make5,make6,make7,MAKE8,MAKE9,MAKE10,MAKE11,MAKE12,MAKE13,MAKE14);

#write.csv(MAKE, "Motor Vehicle/Output/New Folder/Make.csv")

##2.Vehiclestyle
STYLE1 <- data.frame(temp=1, CLAIMID=Vehicle_L61$CLAIMID, VEHICLESTYLE =Vehicle_L61$VEHICLESTYLE)
melt1 <- melt(STYLE1, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE1 <- cast(melt1, CLAIMID~VEHICLESTYLE)

STYLE2 <- data.frame(temp=1, CLAIMID=Vehicle_L62$CLAIMID, VEHICLESTYLE=Vehicle_L62$VEHICLESTYLE)
melt2 <- melt(STYLE2, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE2 <- cast(melt2, CLAIMID~VEHICLESTYLE)

STYLE3 <- data.frame(temp=1, CLAIMID=Vehicle_L63$CLAIMID, VEHICLESTYLE=Vehicle_L63$VEHICLESTYLE)
melt3 <- melt(STYLE3, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE3 <- cast(melt3, CLAIMID~VEHICLESTYLE)

STYLE4 <- data.frame(temp=1, CLAIMID=Vehicle_L64$CLAIMID, VEHICLESTYLE=Vehicle_L64$VEHICLESTYLE)
melt4 <- melt(STYLE4, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE4 <- cast(melt4, CLAIMID~VEHICLESTYLE)

STYLE5 <- data.frame(temp=1, CLAIMID=Vehicle_L65$CLAIMID, VEHICLESTYLE=Vehicle_L65$VEHICLESTYLE)
melt5 <- melt(STYLE5, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE5 <- cast(melt5, CLAIMID~VEHICLESTYLE)

STYLE6 <- data.frame(temp=1, CLAIMID=Vehicle_L66$CLAIMID, VEHICLESTYLE=Vehicle_L66$VEHICLESTYLE)
melt6 <- melt(STYLE6, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE6 <- cast(melt6, CLAIMID~VEHICLESTYLE)

STYLE7 <- data.frame(temp=1, CLAIMID=Vehicle_L67$CLAIMID, VEHICLESTYLE=Vehicle_L67$VEHICLESTYLE)
melt7 <- melt(STYLE7, id=c("CLAIMID", "VEHICLESTYLE"))
STYLE7 <- cast(melt7, CLAIMID~VEHICLESTYLE)

STYLE <- smartbind(STYLE1,STYLE2,STYLE3,STYLE4,STYLE5,STYLE6,STYLE7)

STYLE1<-STYLE2<-STYLE3<-STYLE4<-STYLE5<-STYLE6<-STYLE7<-0
#write.csv(STYLE, "Motor Vehicle/Output/New Folder/Style.csv")

##3.Partytp
TP1 <- data.frame(temp=1, CLAIMID=Vehicle_L61$CLAIMID, PARTYTP =Vehicle_L61$PARTYTP)
melt1 <- melt(TP1, id=c("CLAIMID", "PARTYTP"))
TP1 <- cast(melt1, CLAIMID~PARTYTP)

TP2 <- data.frame(temp=1, CLAIMID=Vehicle_L62$CLAIMID, PARTYTP=Vehicle_L62$PARTYTP)
melt2 <- melt(TP2, id=c("CLAIMID", "PARTYTP"))
TP2 <- cast(melt2, CLAIMID~PARTYTP)

TP3 <- data.frame(temp=1, CLAIMID=Vehicle_L63$CLAIMID, PARTYTP=Vehicle_L63$PARTYTP)
melt3 <- melt(TP3, id=c("CLAIMID", "PARTYTP"))
TP3 <- cast(melt3, CLAIMID~PARTYTP)

TP4 <- data.frame(temp=1, CLAIMID=Vehicle_L64$CLAIMID, PARTYTP=Vehicle_L64$PARTYTP)
melt4 <- melt(TP4, id=c("CLAIMID", "PARTYTP"))
TP4 <- cast(melt4, CLAIMID~PARTYTP)

TP5 <- data.frame(temp=1, CLAIMID=Vehicle_L65$CLAIMID, PARTYTP=Vehicle_L65$PARTYTP)
melt5 <- melt(TP5, id=c("CLAIMID", "PARTYTP"))
TP5 <- cast(melt5, CLAIMID~PARTYTP)

TP6 <- data.frame(temp=1, CLAIMID=Vehicle_L66$CLAIMID, PARTYTP=Vehicle_L66$PARTYTP)
melt6 <- melt(TP6, id=c("CLAIMID", "PARTYTP"))
TP6 <- cast(melt6, CLAIMID~PARTYTP)

TP7 <- data.frame(temp=1, CLAIMID=Vehicle_L67$CLAIMID, PARTYTP=Vehicle_L67$PARTYTP)
melt7 <- melt(TP7, id=c("CLAIMID", "PARTYTP"))
TP7 <- cast(melt7, CLAIMID~PARTYTP)

TP <- smartbind(TP1,TP2,TP3,TP4,TP5,TP6,TP7)

TP1<-TP2<-TP3<-TP4<-TP5<-TP6<-TP7<-0
#write.csv(TP, "Motor Vehicle/Output/New Folder/ThirdParty.csv")

##4.Vehiclelossparty
LOSS1 <- data.frame(temp=1, CLAIMID=Vehicle_L61$CLAIMID, VEHICLELOSSPARTY =Vehicle_L61$VEHICLELOSSPARTY)
melt1 <- melt(LOSS1, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS1 <- cast(melt1, CLAIMID~VEHICLELOSSPARTY)

LOSS2 <- data.frame(temp=1, CLAIMID=Vehicle_L62$CLAIMID, VEHICLELOSSPARTY=Vehicle_L62$VEHICLELOSSPARTY)
melt2 <- melt(LOSS2, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS2 <- cast(melt2, CLAIMID~VEHICLELOSSPARTY)

LOSS3 <- data.frame(temp=1, CLAIMID=Vehicle_L63$CLAIMID, VEHICLELOSSPARTY=Vehicle_L63$VEHICLELOSSPARTY)
melt3 <- melt(LOSS3, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS3 <- cast(melt3, CLAIMID~VEHICLELOSSPARTY)

LOSS4 <- data.frame(temp=1, CLAIMID=Vehicle_L64$CLAIMID, VEHICLELOSSPARTY=Vehicle_L64$VEHICLELOSSPARTY)
melt4 <- melt(LOSS4, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS4 <- cast(melt4, CLAIMID~VEHICLELOSSPARTY)

LOSS5 <- data.frame(temp=1, CLAIMID=Vehicle_L65$CLAIMID, VEHICLELOSSPARTY=Vehicle_L65$VEHICLELOSSPARTY)
melt5 <- melt(LOSS5, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS5 <- cast(melt5, CLAIMID~VEHICLELOSSPARTY)

LOSS6 <- data.frame(temp=1, CLAIMID=Vehicle_L66$CLAIMID, VEHICLELOSSPARTY=Vehicle_L66$VEHICLELOSSPARTY)
melt6 <- melt(LOSS6, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS6 <- cast(melt6, CLAIMID~VEHICLELOSSPARTY)

LOSS7 <- data.frame(temp=1, CLAIMID=Vehicle_L67$CLAIMID, VEHICLELOSSPARTY=Vehicle_L67$VEHICLELOSSPARTY)
melt7 <- melt(LOSS7, id=c("CLAIMID", "VEHICLELOSSPARTY"))
LOSS7 <- cast(melt7, CLAIMID~VEHICLELOSSPARTY)

LOSS <- smartbind(LOSS1,LOSS2,LOSS3,LOSS4,LOSS5,LOSS6,LOSS7)

LOSS1<-LOSS2<-LOSS3<-LOSS4<-LOSS5<-LOSS6<-LOSS7<-0
#write.csv(LOSS, "Motor Vehicle/Output/New Folder/Lossparty.csv")


##5.Vehicledamage
DAMAGE1 <- data.frame(temp=1, CLAIMID=Vehicle_L61$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L61$VEHICLEDAMAGE_Recoded)
melt1 <- melt(DAMAGE1, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE1 <- cast(melt1, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE2 <- data.frame(temp=1, CLAIMID=Vehicle_L62$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L62$VEHICLEDAMAGE_Recoded)
melt2 <- melt(DAMAGE2, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE2 <- cast(melt2, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE3 <- data.frame(temp=1, CLAIMID=Vehicle_L63$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L63$VEHICLEDAMAGE_Recoded)
melt3 <- melt(DAMAGE3, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE3 <- cast(melt3, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE4 <- data.frame(temp=1, CLAIMID=Vehicle_L64$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L64$VEHICLEDAMAGE_Recoded)
melt4 <- melt(DAMAGE4, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE4 <- cast(melt4, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE5 <- data.frame(temp=1, CLAIMID=Vehicle_L65$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L65$VEHICLEDAMAGE_Recoded)
melt5 <- melt(DAMAGE5, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE5 <- cast(melt5, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE6 <- data.frame(temp=1, CLAIMID=Vehicle_L66$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L66$VEHICLEDAMAGE_Recoded)
melt6 <- melt(DAMAGE6, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE6 <- cast(melt6, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE7 <- data.frame(temp=1, CLAIMID=Vehicle_L67$CLAIMID, VEHICLEDAMAGE_Recoded =Vehicle_L67$VEHICLEDAMAGE_Recoded)
melt7 <- melt(DAMAGE7, id=c("CLAIMID", "VEHICLEDAMAGE_Recoded"))
DAMAGE7 <- cast(melt7, CLAIMID~VEHICLEDAMAGE_Recoded)

DAMAGE <- smartbind(DAMAGE1,DAMAGE2,DAMAGE3,DAMAGE4,DAMAGE5,DAMAGE6,DAMAGE7)

colnames(DAMAGE) <- c("CLAIMID", "VEHICLEDAMAGE.No", "VEHICLEDAMAGE.Yes")
DAMAGE1<-DAMAGE2<-DAMAGE3<-DAMAGE4<-DAMAGE5<-DAMAGE6<-DAMAGE7<-0

#write.csv(DAMAGE, "Motor Vehicle/Output/New Folder/DAMAGE.csv")

##6.Vehicletotalloss
V.LOSS1 <- data.frame(temp=1, CLAIMID=Vehicle_L61$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L61$VEHICLETOTALLOSS_Recoded)
melt1 <- melt(V.LOSS1, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS1 <- cast(melt1, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS2 <- data.frame(temp=1, CLAIMID=Vehicle_L62$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L62$VEHICLETOTALLOSS_Recoded)
melt2 <- melt(V.LOSS2, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS2 <- cast(melt2, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS3 <- data.frame(temp=1, CLAIMID=Vehicle_L63$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L63$VEHICLETOTALLOSS_Recoded)
melt3 <- melt(V.LOSS3, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS3 <- cast(melt3, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS4 <- data.frame(temp=1, CLAIMID=Vehicle_L64$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L64$VEHICLETOTALLOSS_Recoded)
melt4 <- melt(V.LOSS4, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS4 <- cast(melt4, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS5 <- data.frame(temp=1, CLAIMID=Vehicle_L65$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L65$VEHICLETOTALLOSS_Recoded)
melt5 <- melt(V.LOSS5, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS5 <- cast(melt5, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS6 <- data.frame(temp=1, CLAIMID=Vehicle_L66$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L66$VEHICLETOTALLOSS_Recoded)
melt6 <- melt(V.LOSS6, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS6 <- cast(melt6, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS7 <- data.frame(temp=1, CLAIMID=Vehicle_L67$CLAIMID, VEHICLETOTALLOSS_Recoded =Vehicle_L67$VEHICLETOTALLOSS_Recoded)
melt7 <- melt(V.LOSS7, id=c("CLAIMID", "VEHICLETOTALLOSS_Recoded"))
V.LOSS7 <- cast(melt7, CLAIMID~VEHICLETOTALLOSS_Recoded)

V.LOSS <- smartbind(V.LOSS1,V.LOSS2,V.LOSS3,V.LOSS4,V.LOSS5,V.LOSS6,V.LOSS7)
colnames(V.LOSS) <- c("CLAIMID", "VEHICLETOTALLOSS.No", "VEHICLETOTALLOSS.Yes")
V.LOSS1<-V.LOSS2<-V.LOSS3<-V.LOSS4<-V.LOSS5<-V.LOSS6<-V.LOSS7<-0
#write.csv(V.LOSS, "Motor Vehicle/Output/New Folder/V.LOSS.csv")

##7.Vehicle Age 
age1<- data.frame(temp=1, 
CLAIMID=Vehicle_L61$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L61$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L61$VEHICLEAGE)
V.AGE1<- reshape(age1,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age2<- data.frame(temp=1, 
CLAIMID=Vehicle_L62$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L62$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L62$VEHICLEAGE)
V.AGE2<- reshape(age2,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age3<- data.frame(temp=1, 
CLAIMID=Vehicle_L63$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L63$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L63$VEHICLEAGE)
V.AGE3<- reshape(age3,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age4<- data.frame(temp=1, 
CLAIMID=Vehicle_L64$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L64$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L64$VEHICLEAGE)
V.AGE4<- reshape(age4,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age5<- data.frame(temp=1, 
CLAIMID=Vehicle_L65$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L65$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L65$VEHICLEAGE)
V.AGE5<- reshape(age5,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age6<- data.frame(temp=1, 
CLAIMID=Vehicle_L66$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L66$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L66$VEHICLEAGE)
V.AGE6<- reshape(age6,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age7<- data.frame(temp=1, 
CLAIMID=Vehicle_L67$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L67$VEHICLEMAKE_Recoded, 
VEHICLEAGE=Vehicle_L67$VEHICLEAGE)
V.AGE7<- reshape(age7,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

V.AGE <- smartbind(V.AGE1,V.AGE2,V.AGE3,V.AGE4,V.AGE5,V.AGE6,V.AGE7)
#write.csv(V.AGE, "Motor Vehicle/Output/New Folder/V.AGE.csv")


##8.DriverAge
age1<- data.frame(temp=1, 
CLAIMID=Vehicle_L61$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L61$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L61$VEHICLEDRIVERAGE)
D.AGE1<- reshape(age1,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age2<- data.frame(temp=1, 
CLAIMID=Vehicle_L62$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L62$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L62$VEHICLEDRIVERAGE)
D.AGE2<- reshape(age2,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age3<- data.frame(temp=1, 
CLAIMID=Vehicle_L63$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L63$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L63$VEHICLEDRIVERAGE)
D.AGE3<- reshape(age3,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age4<- data.frame(temp=1, 
CLAIMID=Vehicle_L64$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L64$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L64$VEHICLEDRIVERAGE)
D.AGE4<- reshape(age4,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age5<- data.frame(temp=1, 
CLAIMID=Vehicle_L65$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L65$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L65$VEHICLEDRIVERAGE)
D.AGE5<- reshape(age5,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age6<- data.frame(temp=1, 
CLAIMID=Vehicle_L66$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L66$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L66$VEHICLEDRIVERAGE)
D.AGE6<- reshape(age6,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

age7<- data.frame(temp=1, 
CLAIMID=Vehicle_L67$CLAIMID, 
VEHICLEMAKE_Recoded=Vehicle_L67$VEHICLEMAKE_Recoded, 
VEHICLEDRIVERAGE=Vehicle_L67$VEHICLEDRIVERAGE)
D.AGE7<- reshape(age7,timevar="VEHICLEMAKE_Recoded", idvar=c("temp", "CLAIMID"), direction="wide")

D.AGE <- smartbind(D.AGE1,D.AGE2,D.AGE3,D.AGE4,D.AGE5,D.AGE6,D.AGE7)
#write.csv(D.AGE, "Motor Vehicle/Output/New Folder/D.AGE.csv")

#Removing duplicates
MAKE <- MAKE[complete.cases(MAKE$CLAIMID),]

##Final Columns required: claimid,vehiclemake,vehicleage,driverage, vehiclelossparty
##vehicledamage, vehicletotalloss, vehiclestyle, partytp
library(plyr)
Vehicle_L7 <- join_all(list(MAKE,V.AGE,D.AGE,STYLE,TP,LOSS,DAMAGE[,1:3],V.LOSS[,1:3]),by='CLAIMID', type='inner')
#cols=c("Vehicle_L7,Vehicle,Cla")
#write.csv(Vehicle_L7,"Final_Vehicle.csv",row.names=F)
cat(paste("\n Done with the Vehicle at",Sys.time()));
#rm(Vehicle_L7)
####################CLAIMS TABLE#######################
Claims_L8=Claim;

# Claims_L9 <- subset(Claims_L8,select=c("CLAIMID","CLOSEDATE","CLAIMDECISION","CLAIMLIABILITY",
# "CLAIMLOSSDATE","CLAIMLODGEDATE","RECOVERYLOCATIONADDRESS1","RECOVERYLOCATIONADDRESS2",
# "RECOVERYLOCATIONCITY","RECOVERYLOCATIONSTATE","RECOVERYLOCATIONPOSTCODE","CLAIMLOSSCAUSE",
# "CLAIMLOSSSUBCAUSE","CLAIMLITIGATION_STATUS","CLAIMPOLICENOTIFIED","CLAIMPOLICEDATE",
# "CLAIMPOLICETIME","CLAIMFIRENOTIFIED","CLAIMEXCESSTOTAL","CLAIMEXCESSAPPLICABLE",
# "CLAIMEXCESSWAIVED"))	#same rows as L8 !!

#write.csv(Claims_L8,"Final_Claims.csv",row.names=F)
rm(Claim)
cat(paste("\n Done with the Claim at",Sys.time()));

####################POLICY TABLE#######################
Policy_L6=Policy
Policy_L7 <- subset(Policy_L6, select=c("CLAIMID","POLICYTYPE"))	#0 rows diff
#write.csv(Policy_L7,"Final_Policy.csv",row.names=F)

cat(paste("\n Done with the Policy at",Sys.time()));

rm(Policy,Policy_L6)
####################REPAIR TABLE#######################
Repair_L4=Repair
Repair_L5 <- aggregate(Repair_L4$QUOTEREPAIRAMOUNT, 
by=list(Repair_L4$ID,Repair_L4$VEHICLEPARTY), FUN=sum)	#844 rows removed

colnames(Repair_L5)<-c("CLAIMID", "VEHICLEPARTY", "QUOTEREPAIRAMOUNT")

#write.csv(Repair_L5,"Final_Repair.csv",row.names=F)

cat(paste("\n Done with the Repair at",Sys.time()));

####################RISK TABLE#######################
risk2 <- subset(Risk,select=c("CLAIMID","RISKMOTORAGREEDVALUE","RISKSUMINSURED"))
#write.csv(risk2,"Final_Risk.csv",row.names=F)
cat(paste("\n Done with the Risk at",Sys.time()));


rm(list=(setdiff(ls(),c("risk2","Policy_L7","Repair_L5","Claims_L8","Vehicle_L7","Party"))))

# setwd("E:\\MyViewsOperationalAnalytics\\MyTables")

# library(RODBC)
# odbc = odbcDriverConnect(connection="server=MYVIEWSOA01;database=Subrogation;trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;") 
# Party=sqlQuery(odbc, "SELECT * FROM V_PartyTable");

####################PARTY TABLE#######################

Party_L5=Party;
rm(Party)
#1.Agents/Agency
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Towing Agency"|
Party_L5$PARTYROLE == "Hire Car Agency"|
Party_L5$PARTYROLE == "Salvage Service"|
Party_L5$PARTYROLE == "Agent"|
Party_L5$PARTYROLE == "Recovery Agent"|
Party_L5$PARTYROLE == "Owning Agency"|
Party_L5$PARTYROLE == "Sharp Agency"|
Party_L5$PARTYROLE == "Broker"|
Party_L5$PARTYROLE == "Vendor"|
Party_L5$PARTYROLE == "Plaintiff Law Firm"|
Party_L5$PARTYROLE == "Defence Law Firm"|
Party_L5$PARTYROLE == "Law Enforcement Agency"|
Party_L5$PARTYROLE == "Service Provider"|
Party_L5$PARTYROLE == "Real Estate Agent"|
Party_L5$PARTYROLE == "Transport Carrier"|
Party_L5$PARTYROLE == "Corporate Agent"|
Party_L5$PARTYROLE == "Registered Operator"|
Party_L5$PARTYROLE == "Appointment Provider"|
Party_L5$PARTYROLE == "Case Management Company"|
Party_L5$PARTYROLE == "Government Agency"|
Party_L5$PARTYROLE == "Collection Agency"|
Party_L5$PARTYROLE == "Motor Fleet Manager"] <- "Agency/Agent"

#2.Assessor
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Primary Assessor"|
Party_L5$PARTYROLE == "External Assessor"|
Party_L5$PARTYROLE == "Assessor"|
Party_L5$PARTYROLE == "CARS Assessor"] <- "Assessor"

#3.Claimant
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Claimant"|
Party_L5$PARTYROLE=="Plaintiff"|
Party_L5$PARTYROLE=="Complainant"|
Party_L5$PARTYROLE=="Recovery On Behalf Of"|
Party_L5$PARTYROLE=="ConvertedClaimant"] <- "Claimant"

#4.Contact
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Main Contact"|
Party_L5$PARTYROLE == "Alternate Contact"|
Party_L5$PARTYROLE == "Negotiation Contact"|
Party_L5$PARTYROLE == "Appointment Contact"] <- "Contact"

#5.Defendant
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Defendant"|
Party_L5$PARTYROLE == "Co-defendant"] <- "Defendant"

#6.Driver
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Driver"|
Party_L5$PARTYROLE == "Listed Driver"] <- "Driver"

#7.Financier
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Financier"] <- "Financier"

#8.Insured
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Insured"|
Party_L5$PARTYROLE == "Additional Insured"|
Party_L5$PARTYROLE == "Insured Representative"] <- "Insured"

#9.Insurer
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Other Insurer"|
Party_L5$PARTYROLE == "Third Party Insurer"] <- "Insurer"


#10.Investigator
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Investigator"] <- "Investigator"

#11.Location
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Assessment Location"] <- "Location"

#12.Other
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Activity Owner"|
Party_L5$PARTYROLE == "Other"|
Party_L5$PARTYROLE == "Supplier"|
Party_L5$PARTYROLE == "Employee"|
Party_L5$PARTYROLE == "Employer"|
Party_L5$PARTYROLE == "Informant"|
Party_L5$PARTYROLE == "Make Safe Provider - General B"|
Party_L5$PARTYROLE == "Person being towed"|
Party_L5$PARTYROLE == "Make Safe Provider - General Builder"|
Party_L5$PARTYROLE == "Project Manager"|
Party_L5$PARTYROLE == "Treatment"|
Party_L5$PARTYROLE == "Doctor"] <- "Others"

#13.Owner
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Owner"|
Party_L5$PARTYROLE == "Mortgagee"|
Party_L5$PARTYROLE == "Unit Owner"|
Party_L5$PARTYROLE == "Animal Owner"] <- "Owner"

#14.Payee
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Payee"] <- "Payee"

#15.Payer
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Recovery Payer"] <- "Payer"

#16.Repair Shop
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Repairer"|
Party_L5$PARTYROLE == "Boat Repairer"|
Party_L5$PARTYROLE == "Repair Shop"|
Party_L5$PARTYROLE == "Motor Repair Shop"] <- "Repair Shop"

#17.Reporter
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Reporter"] <- "Reporter"

#18.Responsible Party
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Responsible Party"|
Party_L5$PARTYROLE == "Responsible Party For Incident"] <- "Responsible Party"

#19.Third Party
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "TP Settlement Party"|
Party_L5$PARTYROLE == "Interested party"|
Party_L5$PARTYROLE == "Passenger"|
Party_L5$PARTYROLE == "Impact Party"|
Party_L5$PARTYROLE == "Suspect"|
Party_L5$PARTYROLE == "Incident Party"|
Party_L5$PARTYROLE == "Case Manager"|
Party_L5$PARTYROLE == "Power of attorney"|
Party_L5$PARTYROLE == "Plaintiff's Attorney"|
Party_L5$PARTYROLE == "Injured Party"|
Party_L5$PARTYROLE == "Neighbour"|
Party_L5$PARTYROLE == "Legal Case Manager"|
Party_L5$PARTYROLE == "Tenant"|
Party_L5$PARTYROLE == "Pedestrian"|
Party_L5$PARTYROLE == "Cyclist"|
Party_L5$PARTYROLE == "Executor"|
Party_L5$PARTYROLE == "Defence Barrister"|
Party_L5$PARTYROLE == "Plaintiff's Barrister"|
Party_L5$PARTYROLE == "Defence Solicitor"|
Party_L5$PARTYROLE == "Solicitor"|
Party_L5$PARTYROLE == "Claimant Dependent"|
Party_L5$PARTYROLE == "Occupant"|
Party_L5$PARTYROLE == "Supervisor"|
Party_L5$PARTYROLE == "Swimmer"|
Party_L5$PARTYROLE == "Engineer"|
Party_L5$PARTYROLE == "Former Insured"|
Party_L5$PARTYROLE == "Sharing Party"|
Party_L5$PARTYROLE == "Architect"|
Party_L5$PARTYROLE == "Lead Paralegal"] <- "Third Party"

#20.Witness
Party_L5$PARTYROLE_Recoded[Party_L5$PARTYROLE == "Witness" |
Party_L5$PARTYROLE == "Observer"] <- "Witness"

#21.Other
Party_L5$PARTYROLE_Recoded=ifelse(Party_L5$PARTYROLE_Recoded!="Witness" 
									& Party_L5$PARTYROLE_Recoded!="Third Party"
									& Party_L5$PARTYROLE_Recoded!="Responsible Party" 
									& Party_L5$PARTYROLE_Recoded!="Reporter" 
									& Party_L5$PARTYROLE_Recoded!="Repair Shop" 
									& Party_L5$PARTYROLE_Recoded!="Owner"
									& Party_L5$PARTYROLE_Recoded!="Payer" 
									& Party_L5$PARTYROLE_Recoded!="Payee"
									& Party_L5$PARTYROLE_Recoded!="Location"
									& Party_L5$PARTYROLE_Recoded!="Investigator"
									& Party_L5$PARTYROLE_Recoded!="Insurer"
									& Party_L5$PARTYROLE_Recoded!="Insured"
									& Party_L5$PARTYROLE_Recoded!="Financier"
									& Party_L5$PARTYROLE_Recoded!="Driver"
									& Party_L5$PARTYROLE_Recoded!="Defendant"
									& Party_L5$PARTYROLE_Recoded!="Contact"
									& Party_L5$PARTYROLE_Recoded!="Claimant"
									& Party_L5$PARTYROLE_Recoded!="Assessor"
									& Party_L5$PARTYROLE_Recoded!="Agency/Agent","Others",Party_L5$PARTYROLE_Recoded)

#Recoding Party year of birth to Party Age
Party_L5$PARTYAGE <- 2015 - Party_L5$PARTYYEAROFBIRTH

#Recoding PartyTP to PartyTP_Recoded


#Casting Party Role recoded
library(reshape)
#Column1:CLAIMID
Party_L5$x=1971089;

#Column3-23: Partyrole_recoded
role <- data.frame(x=Party_L5$x, CLAIMID=Party_L5$CLAIMID, PARTYROLE_Recoded=Party_L5$PARTYROLE_Recoded)
melt <- melt(role, id=c("CLAIMID", "PARTYROLE_Recoded"))
ROLE <- cast(melt, CLAIMID~PARTYROLE_Recoded)
rm(role,melt)
#Column: Party Gender
gender <- data.frame(x=Party_L5$x, CLAIMID=Party_L5$CLAIMID, PARTYROLE_Recoded=Party_L5$PARTYROLE_Recoded, PARTYGENDER=Party_L5$PARTYGENDER)
GENDER <- reshape(gender, timevar="PARTYROLE_Recoded", idvar=c("x", "CLAIMID"), direction="wide")
rm(gender)

#Column: Party Age
age<- data.frame(x=Party_L5$x, CLAIMID=Party_L5$CLAIMID, PARTYROLE_Recoded=Party_L5$PARTYROLE_Recoded, PARTYAGE=Party_L5$PARTYAGE)
AGE<- reshape(age,timevar="PARTYROLE_Recoded", idvar=c("x", "CLAIMID"), direction="wide")
rm(age)

#Column: Injuries
injury <- data.frame(x=Party_L5$x, CLAIMID=Party_L5$CLAIMID, INJURIES=Party_L5$INJURIES)
melt <- melt(injury, id=c("CLAIMID", "INJURIES"))
INJURY <- cast(melt, CLAIMID~INJURIES)
rm(injury)

#Column: BAL
bal <- data.frame(CLAIMID=Party_L5$CLAIMID, BALTESTTAKEN=Party_L5$BALTESTTAKEN)
BAL <- aggregate(bal$BALTESTTAKEN, by=list(CLAIMID=Party_L5$CLAIMID), FUN=max)
colnames(BAL) <- c("CLAIMID", "BALTESTTAKEN")
rm(bal)
#Column: Licence type and partytp
lic <- data.frame(x=Party_L5$x, CLAIMID=Party_L5$CLAIMID, PARTYLICENCETYPE=Party_L5$PARTYLICENCETYPE)
melt <- melt(lic, id=c("CLAIMID", "PARTYLICENCETYPE"))
LIC <- cast(melt, CLAIMID~PARTYLICENCETYPE)
rm(lic)
tp <- data.frame(x=Party_L5$x, CLAIMID=Party_L5$CLAIMID, PARTYTP=Party_L5$PARTYTP)
melt <- melt(tp, id=c("CLAIMID", "PARTYTP"))
TP <- cast(melt, CLAIMID~PARTYTP)
rm(tp)
##Consolidating into a single data frame
##ROLE,GENDER,AGE,INJURY,LIC,TP
library(plyr)
Party_L6=join_all(list(ROLE,GENDER),by='CLAIMID',type='inner')
Party_L6=join_all(list(Party_L6,AGE),by='CLAIMID',type='inner')
Party_L6=join_all(list(Party_L6,INJURY),by='CLAIMID',type='inner')
Party_L6=join_all(list(Party_L6,LIC),by='CLAIMID',type='inner')
Party_L6=join_all(list(Party_L6,TP),by='CLAIMID',type='inner')
#Party_L6 <- join_all(list(ROLE, GENDER, AGE, INJURY, LIC,TP), by='CLAIMID', type='full')
##Extractdate, alcohol, BAL
Party_L7 <- merge(Party_L6, BAL, all=TRUE)
rm(Party_L6)

cat(paste("\n Done with the Party table at",Sys.time()));

# setwd("E:\\MyViewsOperationalAnalytics\\MyTables")

# library(RODBC)
# odbc = odbcDriverConnect(connection="server=MYVIEWSOA01;database=Subrogation;trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;") 

# Policy_L7=read.csv("Final_Policy.csv")
# Repair_L5=read.csv("Final_Repair.csv")
# Vehicle_L7=read.csv("Final_Vehicle.csv")
# Claims_L8=read.csv("Final_Claims.csv")
# Party_L7=read.csv("Final_Party.csv")
# risk2=read.csv("Final_Risk.csv")
###########################################################################################
###################################CREATING MASTER DATA####################################
library(plyr)
Master1 <- join_all(list(Policy_L7, Repair_L5), by='CLAIMID', type='inner')
rm(Policy_L7, Repair_L5)
Master2 <- join_all(list(Master1,Claims_L8), by='CLAIMID', type='inner')
rm(Master1,Claims_L8)
Master3 <- join_all(list(Master2,Vehicle_L7), by='CLAIMID', type='inner')
rm(Master2,Vehicle_L7)
Master4 <- join_all(list(Master3,Party_L7), by='CLAIMID', type='inner')
rm(Master3,Party_L7)
Master5 <- join_all(list(Master4,risk2), by='CLAIMID', type='inner')
rm(Master4,risk2)
mas=Master5
rm(Master5)
library(RODBC)
odbc = odbcDriverConnect(connection="server=MYVIEWSOA01;database=Subrogation;trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;")
Policy=sqlQuery(odbc, "SELECT * FROM V_PolicyTable");


pol2=subset(Policy,select=c("CLAIMID","POLICYPRODUCTTYPE"))
rm(Policy)
mas2 <- join_all(list(mas,pol2), by='CLAIMID', type='inner')
mas=mas2;
rm(mas2,pol2)
################################ ERROR !!!
odbc2 = odbcDriverConnect(connection="server=MYVIEWSOA01;database=Subrogation_Staging;trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;")       
Claim2=sqlQuery(odbc2, "SELECT CLAIMID,Fraud_Indicator,CLAIMSTATUS FROM Staging_Claim");
#Claim2=sqlQuery(odbc2, "SELECT CLAIMID,CLAIMSTATUS FROM Staging_Claim");
c_t2=Claim2;
mas2 <- join_all(list(mas,c_t2), by='CLAIMID', type='inner')
rm(Claim2,c_t2)
mas=mas2
rm(mas2)
###########################################################################################
##############################CREATING NEW VARIABLES#######################################


mas$CLAIMLOSSDATE=as.Date(mas$CLAIMLOSSDATE,"%d%b%Y")
mas$CLAIMLODGEDATE=as.Date(mas$CLAIMLODGEDATE,"%d%b%Y")
mas$CLAIMPOLICEDATE=as.Date(mas$CLAIMPOLICEDATE)

mas$Time_To_Report=ifelse(is.na(mas$CLAIMLOSSDATE) | is.na(mas$CLAIMLODGEDATE),0,-(mas$CLAIMLOSSDATE-mas$CLAIMLODGEDATE));

mas$Time_To_Pnote=ifelse(is.na(mas$CLAIMLOSSDATE) | is.na(mas$CLAIMPOLICEDATE),0,-(mas$CLAIMLOSSDATE-mas$CLAIMPOLICEDATE));

mas$QUOTEREPAIRAMOUNT=ifelse(is.na(mas$QUOTEREPAIRAMOUNT),0,mas$QUOTEREPAIRAMOUNT)
mas$CLAIMEXCESSTOTAL=ifelse(is.na(mas$CLAIMEXCESSTOTAL),0,mas$CLAIMEXCESSTOTAL)
mas$Recover_Potential=mas$QUOTEREPAIRAMOUNT-mas$CLAIMEXCESSTOTAL;

###NEW CODE ADDDED
mas$CLAIMLODGEDATE=as.Date(mas$CLAIMLODGEDATE,"%Y-%m-%d")
mas$CLOSEDATE=as.Date(mas$CLOSEDATE,"%d%b%Y")
mas$CLAIMLIABILITY[mas$CLAIMLIABILITY=="Not at Fault" | mas$CLAIMLIABILITY==""]="No Fault"
mas$CLAIMLIABILITY=as.character(mas$CLAIMLIABILITY)
mas$Y=ifelse(mas$CLAIMLIABILITY=="No Fault",1,0)



######NEW CODE ADDED
mas$EXTRACTDATE=as.Date(Sys.Date(),"%d%b%Y")
mas$CLAIMSTATUS=as.character(mas$CLAIMSTATUS);
mas$Claim_Age=ifelse(is.na(mas$CLOSEDATE) | is.na(mas$CLAIMLODGEDATE),0,ifelse(mas$CLAIMSTATUS=="Closed",mas$CLOSEDATE-mas$CLAIMLODGEDATE,mas$EXTRACTDATE-mas$CLAIMLODGEDATE));

#####################RENAMING
mas$P_Insured=mas$Insured;
# write.csv(mas,"Master_S.csv",row.names=F)
# write.csv(head(mas),"Sample_Master_S.csv",row.names=F)
rm(AGE,BAL,GENDER,INJURY,LIC,melt,odbc2,ROLE,Party_L5,TP);
colnames(mas)[186:194]=c("P_TP1","P_TP2","P_TP3","P_TP4","P_TP5","P_TP6","P_TP7","P_TP8","P_TP9")
colnames(mas)[178:181]=c("P_FATAL","P_INJURED","P_SERIOUS","P_UNHURT");
colnames(mas)[182:185]=c("LT_Learner","LT_Open","LT_Provisional","LT_Unknown")
colnames(mas)[123:139]=paste("P_ROLE_",colnames(mas)[123:139],sep="")
colnames(mas)[c(137,138,140)]=c("P_ROLE_Responsible","P_ROLE_Third.Party","P_ROLE_Unknown")
mas$V_LP_Insured=mas$Insured;
colnames(mas)[112:117]=paste("V_PT_",colnames(mas)[112:117],sep="")
colnames(mas)[118]=c("V_LP_Third.Party")
colnames(mas)[101:111]=paste("V_STYLE_",colnames(mas)[101:111],sep="");
colnames(mas)[25:48]=paste("V_MAKE_",colnames(mas)[25:48],sep="");


cat(paste("\n Done with the Renaming at",Sys.time()));

#######################################################################################################################################################

#########################GROUPING INJURY
mas$P_FATAL=mas$P_FATAL+mas$P_SERIOUS;
mas$P_SERIOUS=NULL;


###########################RE-TRANSPOSING GENDER VARIABLE
mas[,142:159]=lapply(mas[,142:159],as.character)
mas[, 142:159][is.na(mas[, 142:159])] <- "Unknown"
mas[, 142:159][mas[, 142:159]==""] = "Unknown"
mas[,142:159]=lapply(mas[,142:159],tolower)
##IMPORTANT ROLES ARE CLAIMANT, DEFENDANT, DRIVER, INSURED, OWNER, PAYER, RESPONSIBLE PARTY
# mas$GENDER_MALE=0
# mas$GENDER_FEMALE=0
# mas$GENDER_UNKNOWN=0

# 150,152,146,142,148,149
mas$P_Male=ifelse(mas[,142]=="male" | mas[,148]=="male" | mas[,146]=="male" | mas[,148]=="male" | mas[,150]=="male" | mas[,149]=="male" | mas[,152]=="male",1,0)

mas$P_Female=ifelse(mas[,142]=="female" | mas[,148]=="female" | mas[,150]=="female" | mas[,148]=="female" | mas[,146]=="female" | mas[,149]=="female" | mas[,152]=="female",1,0)

mas$P_Unknown=ifelse(mas[,142]=="unknown" | mas[,148]=="unknown" | mas[,150]=="unknown" | mas[,148]=="unknown" | mas[,146]=="unknown" | mas[,149]=="unknown" | mas[,152]=="unknown",1,0)


# for(i in 140:157)
# {
	# for(j in 1:nrow(mas))
	# {
		# if(i==140 | i==141 | i==144| i==145 | i==146 | i==147 | i==151)
		# {
			# str=tolower(mas[j,i])
			# if(str=="male")
			# {
				# mas$GENDER_MALE[j]=mas$GENDER_MALE[j]+1
			# }
			# if(str=="female")
			# {
				# mas$GENDER_FEMALE[j]=mas$GENDER_FEMALE[j]+1
			# }
			# if(str=="unknown")
			# {
				# mas$GENDER_UNKNOWN[j]=mas$GENDER_UNKNOWN[j]+1
			# }
			# # if(mas[j,i]=="Male")
			# # {
				# # mas$GENDER_MALE[j]=mas$GENDER_MALE[j]+1
			# # }
			# # if(mas[j,i]=="Female")
			# # {
				# # mas$GENDER_FEMALE[j]=mas$GENDER_FEMALE[j]+1
			# # }
			# # if(mas[j,i]=="Unknown")
			# # {
				# # mas$GENDER_UNKNOWN[j]=mas$GENDER_UNKNOWN[j]+1
			# # }
		# }
	# }
# }
# colnames(mas)[202:204]=c("P_Male","P_Female","P_Unknown")


##########################RE-TRANSPOSING VEHICLE AGE VARIABLE
#25:48
mas[, 25:48][is.na(mas[, 25:48])] =0;
#len=integer();	#here len is sum of each row..if sum is 1 then only 1 vehicle found, else 2..etc.
age=integer();
len=mas[25]+mas[26]+mas[27]+mas[28]+mas[29]+mas[30]+mas[31]+mas[32]+mas[33]+mas[34]+mas[35]+mas[36]+mas[37]+mas[38]+mas[39]+mas[40]+mas[41]+mas[42]+mas[43]+mas[44]+mas[45]+mas[46]+mas[47]+mas[48]
colnames(len)="len";
len=as.integer(len$len)
# a=1:24
# for(i in 1:nrow(mas))
# {
	# len=c(len,sum(mas[i,25:48]))
# }
mas$Multiple_Veh_Involved=len;
######################FROM HERE
mas$VEHICLEAGE.Unknown=NULL;
mas[, 51:73][is.na(mas[, 51:73])] =0;
s=mas[51]+mas[52]+mas[53]+mas[54]+mas[55]+mas[56]+mas[57]+mas[58]+mas[59]+mas[60]+mas[61]+mas[62]+mas[63]+mas[64]+mas[65]+mas[66]+mas[67]+mas[68]+mas[69]+mas[70]+mas[71]+mas[72]+mas[73]
colnames(s)="sum"
s=s$sum;
mas2=mas[,51:73];
m=apply(mas2, 1, max) 
age=ifelse(len==1,s,m)
# for(i in 1:nrow(mas))
# {
	# if(len[i]==1)
	# {
		# age=c(age,mas[i,51:73][!is.na(mas[i,51:73])]);
	# }
	# else
	# {
		# age=c(age,max(mas[i,51:73][!is.na(mas[i,51:73])]));
	# }
# }
mas$Vehicle_Age=age;

# LT 2 : Less than and equals to 2
# 2 - 15 : Greater than 2 and less than equals to 15
# 15 - 50 : Greater than 15 and less than equals to 50
# 50 > : Greater than and equals to 50
mas[,51:73]=lapply(mas[,51:73],as.numeric)
mas[, 51:73][is.na(mas[, 51:73])]=0;
mas$V_Age_LT_2=ifelse(mas[,51] < 2 | mas[,52] < 2 | mas[,53] < 2 | mas[,54] < 2 | mas[,55] < 2 | mas[,56] < 2 | mas[,57] < 2 | mas[,58] < 2 | mas[,59] < 2 | mas[,60] < 2 | mas[,61] < 2 | mas[,62] < 2 | mas[,63] < 2 | mas[,64] < 2 | mas[,65] < 2 | mas[,66] < 2 | mas[,67] < 2 | mas[,68] < 2 | mas[,69] < 2 | mas[,70] < 2 | mas[,71] < 2 | mas[,72] < 2 | mas[,73] < 2 ,1,0)
mas$V_Age_2_15=ifelse((mas[,51] >=2 | mas[,52] >=2 | mas[,53] >=2 | mas[,54] >=2 | mas[,55] >=2 | mas[,56] >=2 | mas[,57] >=2 | mas[,58] >=2 | mas[,59] >=2 | mas[,60] >=2 | mas[,61] >=2 | mas[,62] >=2 | mas[,63] >=2 | mas[,64] >=2 | mas[,65] >=2 | mas[,66] >=2 | mas[,67] >=2 | mas[,68] >=2 | mas[,69] >=2 | mas[,70] >=2 | mas[,71] >=2 | mas[,72] >=2 | mas[,73] >=2) & (mas[,52] < 15 | mas[,53] < 15 | mas[,54] < 15 | mas[,55] < 15 | mas[,56] < 15 | mas[,57] < 15 | mas[,58] < 15 | mas[,59] < 15 | mas[,60] < 15 | mas[,61] < 15 | mas[,62] < 15 | mas[,63] < 15 | mas[,64] < 15 | mas[,65] < 15 | mas[,66] < 15 | mas[,67] < 15 | mas[,68] < 15 | mas[,69] < 15 | mas[,70] < 15 | mas[,71] < 15 | mas[,72] < 15 | mas[,73] < 15),1,0)
mas$V_Age_15_50=ifelse((mas[,51] >=15 | mas[,52] >=15 | mas[,53] >=15 | mas[,54] >=15 | mas[,55] >=15 | mas[,56] >=15 | mas[,57] >=15 | mas[,58] >=15 | mas[,59] >=15 | mas[,60] >=15 | mas[,61] >=15 | mas[,62] >=15 | mas[,63] >=15 | mas[,64] >=15 | mas[,65] >=15 | mas[,66] >=15 | mas[,67] >=15 | mas[,68] >=15 | mas[,69] >=15 | mas[,70] >=15 | mas[,71] >=15 | mas[,72] >=15 | mas[,73] >=15) & (mas[,52] < 50 | mas[,53] < 50 | mas[,54] < 50 | mas[,55] < 50 | mas[,56] < 50 | mas[,57] < 50 | mas[,58] < 50 | mas[,59] < 50 | mas[,60] < 50 | mas[,61] < 50 | mas[,62] < 50 | mas[,63] < 50 | mas[,64] < 50 | mas[,65] < 50 | mas[,66] < 50 | mas[,67] < 50 | mas[,68] < 50 | mas[,69] < 50 | mas[,70] < 50 | mas[,71] < 50 | mas[,72] < 50 | mas[,73] < 50),1,0)
mas$V_Age_GT_50=ifelse(mas[,51] >=50 | mas[,52] >=50 | mas[,53] >=50 | mas[,54] >=50 | mas[,55] >=50 | mas[,56] >=50 | mas[,57] >=50 | mas[,58] >=50 | mas[,59] >=50 | mas[,60] >=50 | mas[,61] >=50 | mas[,62] >=50 | mas[,63] >=50 | mas[,64] >=50 | mas[,65] >=50 | mas[,66] >=50 | mas[,67] >=50 | mas[,68] >=50 | mas[,69] >=50 | mas[,70] >=50 | mas[,71] >=50 | mas[,72] >=50 | mas[,73] >=50,1,0)

# mas$V_Age_LT_2=0
# mas$V_Age_2_15=0
# mas$V_Age_15_50=0
# mas$V_Age_GT_50=0
# for(i in 52:74)
# {
	# for(j in 1:nrow(mas))
	# {	
		# if(length(mas[j,i][!is.na(mas[j,i])])!=0)
		# {
			# if(mas[j,i][!is.na(mas[j,i])]<2)
			# {
				# mas$V_Age_LT_2[j]=mas$V_Age_LT_2[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=2 & mas[j,i]<15)
			# {
				# mas$V_Age_2_15[j]=mas$V_Age_2_15[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=15 & mas[j,i]<50)
			# {
				# mas$V_Age_15_50[j]=mas$V_Age_15_50[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=50)
			# {
				# mas$V_Age_GT_50[j]=mas$V_Age_GT_50[j]+1
			# }
		# }
	# }
# }

# ##RECODE THE ABOVE TO BINARY !!
# mas$V_Age_LT_2=ifelse(mas$V_Age_LT_2==0,0,1);
# mas$V_Age_2_15=ifelse(mas$V_Age_2_15==0,0,1);
# mas$V_Age_15_50=ifelse(mas$V_Age_15_50==0,0,1);
# mas$V_Age_GT_50=ifelse(mas$V_Age_GT_50==0,0,1);

##########################RE-TRANSPOSING SUM INSURED
mas$Risk_Motor_Agreed_Value=NULL


####### FOR BAL TEST TAKEN
mas$BALTESTTAKEN[is.na(mas$BALTESTTAKEN)]="No";
mas$Alc_Drug_Ind=ifelse(mas$BALTESTTAKEN=="Yes",1,0)


####### FOR VEHICLE DAMAGE AND TOTAL LOSS
mas$V_Damage_Ind=ifelse(mas$VEHICLEDAMAGE.Yes==1,1,0);
mas$V_Tot_Loss_Ind=ifelse(mas$VEHICLETOTALLOSS.Yes==1,1,0);
mas$VEHICLEDAMAGE.Yes=NULL;
mas$VEHICLEDAMAGE.No=NULL;
mas$VEHICLETOTALLOSS.Yes=NULL;
mas$VEHICLETOTALLOSS.No=NULL;

####### RETRANSPOSING PARTY ROLES (SUMMING UP)

mas[, 118:135][is.na(mas[, 118:135])] =0;
len=mas[118]+mas[119]+mas[120]+mas[121]+mas[122]+mas[123]+mas[124]+mas[125]+mas[126]+mas[127]+mas[128]+mas[129]+mas[130]+mas[131]+mas[132]+mas[133]+mas[134]+mas[135]
colnames(len)="len";

mas$P_Roles_Count=len$len;



###### RETRANSPOSING VEHICLE LOSS PARTY
mas$V_LOSS_PARTY_Ind=ifelse(mas$V_LP_Third.Party==1 & mas$V_LP_Insured==1,2,ifelse(mas$V_LP_Insured==1 & mas$V_LP_Third.Party!=1,1,0))


###### RETRANSPOSING PARTY AGE (GROUPING)

mas[, 155:171][is.na(mas[, 155:171])] =0;

mas$P_LT_18=ifelse(mas[,155] < 18 | mas[,156] < 18 | mas[,157] < 18 | mas[,158] < 18 | mas[,159] < 18 | mas[,160] < 18 | mas[,161] < 18 | mas[,162] < 18 | mas[,163] < 18 | mas[,164] < 18 | mas[,165] < 18 | mas[,166] < 18 | mas[,167] < 18 | mas[,168] < 18 | mas[,169] < 18 | mas[,170] < 18 | mas[,171] < 18,1,0)
mas$P_18_25=ifelse((mas[,155] >=18 | mas[,156] >=18 | mas[,157] >=18 | mas[,158] >=18 | mas[,159] >=18 | mas[,160] >=18 | mas[,161] >=18 | mas[,162] >=18 | mas[,163] >=18 | mas[,164] >=18 | mas[,165] >=18 | mas[,166] >=18 | mas[,167] >=18 | mas[,168] >=18 | mas[,169] >=18 | mas[,170] >=18 | mas[,171] >=18)&(mas[,155] < 25 | mas[,156] < 25 | mas[,157] < 25 | mas[,158] < 25 | mas[,159] < 25 | mas[,160] < 25 | mas[,161] < 25 | mas[,162] < 25 | mas[,163] < 25 | mas[,164] < 25 | mas[,165] < 25 | mas[,166] < 25 | mas[,167] < 25 | mas[,168] < 25 | mas[,169] < 25 | mas[,170] < 25 | mas[,171] < 25),1,0)
mas$P_25_35=ifelse((mas[,155] >=25 | mas[,156] >=25 | mas[,157] >=25 | mas[,158] >=25 | mas[,159] >=25 | mas[,160] >=25 | mas[,161] >=25 | mas[,162] >=25 | mas[,163] >=25 | mas[,164] >=25 | mas[,165] >=25 | mas[,166] >=25 | mas[,167] >=25 | mas[,168] >=25 | mas[,169] >=25 | mas[,170] >=25 | mas[,171] >=25)&(mas[,155] < 35 | mas[,156] < 35 | mas[,157] < 35 | mas[,158] < 35 | mas[,159] < 35 | mas[,160] < 35 | mas[,161] < 35 | mas[,162] < 35 | mas[,163] < 35 | mas[,164] < 35 | mas[,165] < 35 | mas[,166] < 35 | mas[,167] < 35 | mas[,168] < 35 | mas[,169] < 35 | mas[,170] < 35 | mas[,171] < 35),1,0)
mas$P_35_45=ifelse((mas[,155] >=35 | mas[,156] >=35 | mas[,157] >=35 | mas[,158] >=35 | mas[,159] >=35 | mas[,160] >=35 | mas[,161] >=35 | mas[,162] >=35 | mas[,163] >=35 | mas[,164] >=35 | mas[,165] >=35 | mas[,166] >=35 | mas[,167] >=35 | mas[,168] >=35 | mas[,169] >=35 | mas[,170] >=35 | mas[,171] >=35)&(mas[,155] < 45 | mas[,156] < 45 | mas[,157] < 45 | mas[,158] < 45 | mas[,159] < 45 | mas[,160] < 45 | mas[,161] < 45 | mas[,162] < 45 | mas[,163] < 45 | mas[,164] < 45 | mas[,165] < 45 | mas[,166] < 45 | mas[,167] < 45 | mas[,168] < 45 | mas[,169] < 45 | mas[,170] < 45 | mas[,171] < 45),1,0)
mas$P_45_55=ifelse((mas[,155] >=45 | mas[,156] >=45 | mas[,157] >=45 | mas[,158] >=45 | mas[,159] >=45 | mas[,160] >=45 | mas[,161] >=45 | mas[,162] >=45 | mas[,163] >=45 | mas[,164] >=45 | mas[,165] >=45 | mas[,166] >=45 | mas[,167] >=45 | mas[,168] >=45 | mas[,169] >=45 | mas[,170] >=45 | mas[,171] >=45)&(mas[,155] < 55 | mas[,156] < 55 | mas[,157] < 55 | mas[,158] < 55 | mas[,159] < 55 | mas[,160] < 55 | mas[,161] < 55 | mas[,162] < 55 | mas[,163] < 55 | mas[,164] < 55 | mas[,165] < 55 | mas[,166] < 55 | mas[,167] < 55 | mas[,168] < 55 | mas[,169] < 55 | mas[,170] < 55 | mas[,171] < 55),1,0)
mas$P_55_65=ifelse((mas[,155] >=55 | mas[,156] >=55 | mas[,157] >=55 | mas[,158] >=55 | mas[,159] >=55 | mas[,160] >=55 | mas[,161] >=55 | mas[,162] >=55 | mas[,163] >=55 | mas[,164] >=55 | mas[,165] >=55 | mas[,166] >=55 | mas[,167] >=55 | mas[,168] >=55 | mas[,169] >=55 | mas[,170] >=55 | mas[,171] >=55)&(mas[,155] < 65 | mas[,156] < 65 | mas[,157] < 65 | mas[,158] < 65 | mas[,159] < 65 | mas[,160] < 65 | mas[,161] < 65 | mas[,162] < 65 | mas[,163] < 65 | mas[,164] < 65 | mas[,165] < 65 | mas[,166] < 65 | mas[,167] < 65 | mas[,168] < 65 | mas[,169] < 65 | mas[,170] < 65 | mas[,171] < 65),1,0)
mas$P_GT_65=ifelse(mas[,155] >=65 | mas[,156] >=65 | mas[,157] >=65 | mas[,158] >=65 | mas[,159] >=65 | mas[,160] >=65 | mas[,161] >=65 | mas[,162] >=65 | mas[,163] >=65 | mas[,164] >=65 | mas[,165] >=65 | mas[,166] >=65 | mas[,167] >=65 | mas[,168] >=65 | mas[,169] >=65 | mas[,170] >=65 | mas[,171] >=65,1,0)


# for(i in 155:171)
# {
	# for(j in 1:nrow(mas))
	# {	
		# if(length(mas[j,i][!is.na(mas[j,i])])!=0)
		# {
			# if(mas[j,i][!is.na(mas[j,i])]<18)
			# {
				# mas$P_LT_18[j]=mas$P_LT_18[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=18 & mas[j,i]<25)
			# {
				# mas$P_18_25[j]=mas$P_18_25[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=25 & mas[j,i]<35)
			# {
				# mas$P_25_35[j]=mas$P_25_35[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=35 & mas[j,i]<45)
			# {
				# mas$P_35_45[j]=mas$P_35_45[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=45 & mas[j,i]<55)
			# {
				# mas$P_45_55[j]=mas$P_45_55[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=55 & mas[j,i]<65)
			# {
				# mas$P_55_65[j]=mas$P_55_65[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=65)
			# {
				# mas$P_GT_65[j]=mas$P_GT_65[j]+1
			# }
		# }
	# }
# }
####REGROUPED AS
# mas$P_LT_18=0
# mas$P_18_25=0
# mas$P_25_35=0
# mas$P_35_55=0***
# mas$P_55_65=0
# mas$P_GT_65=0
mas$P_35_55=mas$P_35_45+mas$P_45_55;
mas$P_35_55=ifelse(mas$P_35_55>=1,1,0);
mas$P_45_55=NULL;
# mas$P_35_45=NULL;
# colnames(mas)[220]="P_35_55"


mas[, 75:98][is.na(mas[, 75:98])] =0;
###### RETRANSPOSING DRIVER AGE (GROUPING)
mas$D_LT_18=ifelse(mas[,75] < 18 | mas[,76] < 18 | mas[,77] < 18 | mas[,78] < 18 | mas[,79] < 18 | mas[,80] < 18 | mas[,81] < 18 | mas[,82] < 18 | mas[,83] < 18 | mas[,84] < 18 | mas[,85] < 18 | mas[,86] < 18 | mas[,87] < 18 | mas[,88] < 18 | mas[,89] < 18 | mas[,90] < 18 | mas[,91] < 18 | mas[,92] < 18 | mas[,93] < 18 | mas[,94] < 18 | mas[,95] < 18 | mas[,96] < 18 | mas[,97] < 18 | mas[,98] < 18,1,0)
mas$D_18_25=ifelse((mas[,75] >=18 | mas[,76] >=18 | mas[,77] >=18 | mas[,78] >=18 | mas[,79] >=18 | mas[,80] >=18 | mas[,81] >=18 | mas[,82] >=18 | mas[,83] >=18 | mas[,84] >=18 | mas[,85] >=18 | mas[,86] >=18 | mas[,87] >=18 | mas[,88] >=18 | mas[,89] >=18 | mas[,90] >=18 | mas[,91] >=18 | mas[,92] >=18 | mas[,93] >=18 | mas[,94] >=18 | mas[,95] >=18 | mas[,96] >=18 | mas[,97] >=18 | mas[,98] >=18)&(mas[,75] < 25 | mas[,76] < 25 | mas[,77] < 25 | mas[,78] < 25 | mas[,79] < 25 | mas[,80] < 25 | mas[,81] < 25 | mas[,82] < 25 | mas[,83] < 25 | mas[,84] < 25 | mas[,85] < 25 | mas[,86] < 25 | mas[,87] < 25 | mas[,88] < 25 | mas[,89] < 25 | mas[,90] < 25 | mas[,91] < 25 | mas[,92] < 25 | mas[,93] < 25 | mas[,94] < 25 | mas[,95] < 25 | mas[,96] < 25 | mas[,97] < 25 | mas[,98]),1,0)
mas$D_25_35=ifelse((mas[,75] >=25 | mas[,76] >=25 | mas[,77] >=25 | mas[,78] >=25 | mas[,79] >=25 | mas[,80] >=25 | mas[,81] >=25 | mas[,82] >=25 | mas[,83] >=25 | mas[,84] >=25 | mas[,85] >=25 | mas[,86] >=25 | mas[,87] >=25 | mas[,88] >=25 | mas[,89] >=25 | mas[,90] >=25 | mas[,91] >=25 | mas[,92] >=25 | mas[,93] >=25 | mas[,94] >=25 | mas[,95] >=25 | mas[,96] >=25 | mas[,97] >=25 | mas[,98] >=25)&(mas[,75] < 35 | mas[,76] < 35 | mas[,77] < 35 | mas[,78] < 35 | mas[,79] < 35 | mas[,80] < 35 | mas[,81] < 35 | mas[,82] < 35 | mas[,83] < 35 | mas[,84] < 35 | mas[,85] < 35 | mas[,86] < 35 | mas[,87] < 35 | mas[,88] < 35 | mas[,89] < 35 | mas[,90] < 35 | mas[,91] < 35 | mas[,92] < 35 | mas[,93] < 35 | mas[,94] < 35 | mas[,95] < 35 | mas[,96] < 35 | mas[,97] < 35 | mas[,98]),1,0)
mas$D_35_45=ifelse((mas[,75] >=35 | mas[,76] >=35 | mas[,77] >=35 | mas[,78] >=35 | mas[,79] >=35 | mas[,80] >=35 | mas[,81] >=35 | mas[,82] >=35 | mas[,83] >=35 | mas[,84] >=35 | mas[,85] >=35 | mas[,86] >=35 | mas[,87] >=35 | mas[,88] >=35 | mas[,89] >=35 | mas[,90] >=35 | mas[,91] >=35 | mas[,92] >=35 | mas[,93] >=35 | mas[,94] >=35 | mas[,95] >=35 | mas[,96] >=35 | mas[,97] >=35 | mas[,98] >=35)&(mas[,75] < 45 | mas[,76] < 45 | mas[,77] < 45 | mas[,78] < 45 | mas[,79] < 45 | mas[,80] < 45 | mas[,81] < 45 | mas[,82] < 45 | mas[,83] < 45 | mas[,84] < 45 | mas[,85] < 45 | mas[,86] < 45 | mas[,87] < 45 | mas[,88] < 45 | mas[,89] < 45 | mas[,90] < 45 | mas[,91] < 45 | mas[,92] < 45 | mas[,93] < 45 | mas[,94] < 45 | mas[,95] < 45 | mas[,96] < 45 | mas[,97] < 45 | mas[,98]),1,0)
mas$D_45_55=ifelse((mas[,75] >=45 | mas[,76] >=45 | mas[,77] >=45 | mas[,78] >=45 | mas[,79] >=45 | mas[,80] >=45 | mas[,81] >=45 | mas[,82] >=45 | mas[,83] >=45 | mas[,84] >=45 | mas[,85] >=45 | mas[,86] >=45 | mas[,87] >=45 | mas[,88] >=45 | mas[,89] >=45 | mas[,90] >=45 | mas[,91] >=45 | mas[,92] >=45 | mas[,93] >=45 | mas[,94] >=45 | mas[,95] >=45 | mas[,96] >=45 | mas[,97] >=45 | mas[,98] >=45)&(mas[,75] < 55 | mas[,76] < 55 | mas[,77] < 55 | mas[,78] < 55 | mas[,79] < 55 | mas[,80] < 55 | mas[,81] < 55 | mas[,82] < 55 | mas[,83] < 55 | mas[,84] < 55 | mas[,85] < 55 | mas[,86] < 55 | mas[,87] < 55 | mas[,88] < 55 | mas[,89] < 55 | mas[,90] < 55 | mas[,91] < 55 | mas[,92] < 55 | mas[,93] < 55 | mas[,94] < 55 | mas[,95] < 55 | mas[,96] < 55 | mas[,97] < 55 | mas[,98]),1,0)
mas$D_55_65=ifelse((mas[,75] >=55 | mas[,76] >=55 | mas[,77] >=55 | mas[,78] >=55 | mas[,79] >=55 | mas[,80] >=55 | mas[,81] >=55 | mas[,82] >=55 | mas[,83] >=55 | mas[,84] >=55 | mas[,85] >=55 | mas[,86] >=55 | mas[,87] >=55 | mas[,88] >=55 | mas[,89] >=55 | mas[,90] >=55 | mas[,91] >=55 | mas[,92] >=55 | mas[,93] >=55 | mas[,94] >=55 | mas[,95] >=55 | mas[,96] >=55 | mas[,97] >=55 | mas[,98] >=55)&(mas[,75] < 65 | mas[,76] < 65 | mas[,77] < 65 | mas[,78] < 65 | mas[,79] < 65 | mas[,80] < 65 | mas[,81] < 65 | mas[,82] < 65 | mas[,83] < 65 | mas[,84] < 65 | mas[,85] < 65 | mas[,86] < 65 | mas[,87] < 65 | mas[,88] < 65 | mas[,89] < 65 | mas[,90] < 65 | mas[,91] < 65 | mas[,92] < 65 | mas[,93] < 65 | mas[,94] < 65 | mas[,95] < 65 | mas[,96] < 65 | mas[,97] < 65 | mas[,98]),1,0)
mas$D_GT_65=ifelse(mas[,75] >=65 | mas[,76] >=65 | mas[,77] >=65 | mas[,78] >=65 | mas[,79] >=65 | mas[,80] >=65 | mas[,81] >=65 | mas[,82] >=65 | mas[,83] >=65 | mas[,84] >=65 | mas[,85] >=65 | mas[,86] >=65 | mas[,87] >=65 | mas[,88] >=65 | mas[,89] >=65 | mas[,90] >=65 | mas[,91] >=65 | mas[,92] >=65 | mas[,93] >=65 | mas[,94] >=65 | mas[,95] >=65 | mas[,96] >=65 | mas[,97] >=65 | mas[,98] >=65,1,0)


# for(i in 76:99)
# {
	# for(j in 1:nrow(mas))
	# {	
		# if(length(mas[j,i][!is.na(mas[j,i])])!=0)
		# {
			# if(mas[j,i][!is.na(mas[j,i])]<18)
			# {
				# mas$D_LT_18[j]=mas$D_LT_18[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=18 & mas[j,i]<25)
			# {
				# mas$D_18_25[j]=mas$D_18_25[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=25 & mas[j,i]<35)
			# {
				# mas$D_25_35[j]=mas$D_25_35[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=35 & mas[j,i]<45)
			# {
				# mas$D_35_45[j]=mas$D_35_45[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=45 & mas[j,i]<55)
			# {
				# mas$D_45_55[j]=mas$D_45_55[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=55 & mas[j,i]<65)
			# {
				# mas$D_55_65[j]=mas$D_55_65[j]+1
			# }
			# else if(mas[j,i][!is.na(mas[j,i])]>=65)
			# {
				# mas$D_GT_65[j]=mas$D_GT_65[j]+1
			# }
		# }
	# }
# }
#####REGROUPED AS
# mas$D_LT_18=0
# mas$D_18_25=0
# mas$D_25_35=0
# mas$D_35_55=0***
# mas$D_55_65=0
# mas$D_GT_65=0

mas$D_35_55=mas$D_35_45+mas$D_45_55;
mas$D_35_55=ifelse(mas$D_35_55>=1,1,0);
mas$D_45_55=NULL;
# mas$D_35_45=NULL;
# colnames(mas)[226]="D_35_55"


cat(paste("\n Done with the Ages at",Sys.time()));

#################### RETRANSPOSING STYLE OF THE VEHICLE !!
#100:112
mas[, 100:110][is.na(mas[, 100:110])] = 0

# Heavy_Vehicle : Truck, Bus (100,110)
# Medium_Vehicle : Caravan, Classic, Motor Home, Standard, Trailer, Veteran.Vintage (101,102,104,108,109,112)
# Small_Vehicle : (2Wheeler) Moped.or.Scooter, Motor cycle, Off.Road.Bike, Unique Vehicle (103,105,106,111)
# Others : Other (107)


mas$Heavy_Vehicle=ifelse(mas[,100]>0 | mas[,110]>0,1,0);
mas$Small_Vehicle=ifelse(mas[,101]>0 | mas[,102]>0 | mas[,104]>0 | mas[,108]>0 | mas[,109]>0 | mas[,112]>0,1,0);
mas$Medium_Vehicle=ifelse(mas[,103]>0 | mas[,105]>0 | mas[,106]>0 | mas[,111]>0,1,0);
mas$Others=ifelse(mas[,107]>0,1,0);
mas$Others=ifelse(mas$Heavy_Vehicle==0 & mas$Small_Vehicle==0 & mas$Medium_Vehicle==0,1,mas$Others)

# for(i in 100:110)
# {
	# for(j in 1:nrow(mas))
	# {
		# if(i==100 | i==110)
		# {
			# if(mas[j,i]>0)
			# {
				# mas$Heavy_Vehicle[j]=mas$Heavy_Vehicle[j]+1;
			# }
		# }
		# else if(i==101 | i==102 | i==104 | i==108 | i==109 | i==112)
		# {
			# if(mas[j,i]>0)
			# {
				# mas$Medium_Vehicle[j]=mas$Medium_Vehicle[j]+1;
			# }
		# }
		# else if(i==103 | i==105 | i==106 | i==111)
		# {
			# if(mas[j,i]>0)
			# {
				# mas$Small_Vehicle[j]=mas$Small_Vehicle[j]+1;
			# }
		# }
		# else if(i==107)
		# {
			# if(mas[j,i]>0)
			# {
				# mas$Others[j]=mas$Others[j]+1;
			# }
		# }
	# }
# }
############## CREATING CUSTOMER DATA
mas$Customer_Age=ifelse(!is.na(mas$PARTYAGE.Claimant),mas$PARTYAGE.Claimant,NA)
gen=as.character(mas$PARTYGENDER.Claimant);
mas$Customer_Gender=ifelse(!is.na(gen) | gen=="",gen, "Unknown")




#################RECOVERY INDICATOR
#13-17
mas$Recovery_Indicator=ifelse(mas$RECOVERYLOCATIONADDRESS1=="" | mas$RECOVERYLOCATIONADDRESS2=="" | mas$RECOVERYLOCATIONCITY=="" | mas$RECOVERYLOCATIONSTATE=="" | is.na(mas$RECOVERYLOCATIONPOSTCODE) |mas$RECOVERYLOCATIONPOSTCODE=="",0,1)
mas$Recovery_Indicator[is.na(mas$Recovery_Indicator)]=1

#################EXCESS WAIVED INDICATOR
mas$Excess_Waived_Ind=ifelse(mas$CLAIMEXCESSWAIVED=="Yes",1,0)


#################CLAIM LOSS CAUSE GROUPING
# Damage
# Mechanical
# Natural
# Other
# Theft

cols=names(table(mas$CLAIMLOSSCAUSE,useNA="ifany"))
mas$C_LC_Damage=ifelse(mas$CLAIMLOSSCAUSE==cols[2] | mas$CLAIMLOSSCAUSE==cols[3] , 1 , 0 )
mas$C_LC_Mechanical=ifelse(mas$CLAIMLOSSCAUSE==cols[4],1,0)
mas$C_LC_Natural=ifelse(mas$CLAIMLOSSCAUSE==cols[5],1,0)
mas$C_LC_Other=ifelse(mas$CLAIMLOSSCAUSE==cols[6] | mas$CLAIMLOSSCAUSE==cols[1],1,0)
mas$C_LC_Theft=ifelse(mas$CLAIMLOSSCAUSE==cols[7],1,0)
mas$C_LC_Other=ifelse(mas$C_LC_Damage==0 & mas$C_LC_Mechanical==0 & mas$C_LC_Natural==0 & mas$C_LC_Other==0 & mas$C_LC_Theft==0,1,0)

#################Risk_Sum_Insured GROUPING
Risk_Sum_Insured=ifelse(is.na(mas$RISKSUMINSURED),0,mas$RISKSUMINSURED)
mas$RSI_LT_15K=0
mas$RSI_15K_30K=0
mas$RSI_GT_30K=0
mas$RSI_LT_15K=ifelse(Risk_Sum_Insured<15000,mas$RSI_LT_15K+1,mas$RSI_LT_15K);
mas$RSI_15K_30K=ifelse(Risk_Sum_Insured>=15000 & Risk_Sum_Insured<30000,mas$RSI_15K_30K+1,mas$RSI_15K_30K);
mas$RSI_GT_30K=ifelse(Risk_Sum_Insured>=30000,mas$RSI_GT_30K+1,mas$RSI_GT_30K);

#################QUOTEREPAIRAMOUNT GROUPING
#QUOTEREPAIRAMOUNT
# LT 2K
# GTE 2K LT 4K
# GTE 4K
QUOTEREPAIRAMOUNT=ifelse(is.na(mas$QUOTEREPAIRAMOUNT),0,mas$QUOTEREPAIRAMOUNT)
mas$QRA_LT_2K=0
mas$QRA_2K_4K=0
mas$QRA_GT_4K=0
mas$QRA_LT_2K=ifelse(QUOTEREPAIRAMOUNT<2000,mas$QRA_LT_2K+1,mas$QRA_LT_2K);
mas$QRA_2K_4K=ifelse(QUOTEREPAIRAMOUNT>=2000 & QUOTEREPAIRAMOUNT<4000,mas$QRA_2K_4K+1,mas$QRA_2K_4K);
mas$QRA_GT_4K=ifelse(QUOTEREPAIRAMOUNT>=4000,mas$QRA_GT_4K+1,mas$QRA_GT_4K);

#################EXCESS TOTAL GROUPING
#EXCESS TOTAL	(FOR NOW NOT REQUIRED)
# LT 6
# GTE 6 LT 7
# GTE 7
CLAIMEXCESSTOTAL=ifelse(is.na(mas$CLAIMEXCESSTOTAL),0,mas$CLAIMEXCESSTOTAL)
mas$CET_LT_6=0
mas$CET_6_7=0
mas$CET_GT_7=0
mas$CET_LT_6=ifelse(CLAIMEXCESSTOTAL<6,mas$CET_LT_6+1,mas$CET_LT_6);
mas$CET_6_7=ifelse(CLAIMEXCESSTOTAL>=6 & CLAIMEXCESSTOTAL<7,mas$CET_6_7+1,mas$CET_6_7);
mas$CET_GT_7=ifelse(CLAIMEXCESSTOTAL>=7,mas$CET_GT_7+1,mas$CET_GT_7);

#################EXCESS APPLICABLE GROUPING
#EXCESS APPLICABLE	(FOR NOW NOT REQUIRED)
# ET 0
# GT 0 LTE 600
# GT 600
CLAIMEXCESSAPPLICABLE=ifelse(is.na(mas$CLAIMEXCESSAPPLICABLE),0,mas$CLAIMEXCESSAPPLICABLE)
mas$CEA_ET_0=0
mas$CEA_0_600=0
mas$CEA_GT_600=0
mas$CEA_ET_0=ifelse(CLAIMEXCESSAPPLICABLE==0,mas$CEA_ET_0+1,mas$CEA_ET_0);
mas$CEA_0_600=ifelse(CLAIMEXCESSAPPLICABLE>0 & CLAIMEXCESSAPPLICABLE<=600,mas$CEA_0_600+1,mas$CEA_0_600);
mas$CEA_GT_600=ifelse(CLAIMEXCESSAPPLICABLE>600,mas$CEA_GT_600+1,mas$CEA_GT_600);
rm(CLAIMEXCESSAPPLICABLE,CLAIMEXCESSTOTAL,QUOTEREPAIRAMOUNT,Risk_Sum_Insured)



mas$Litigation_Ind=ifelse(mas$CLAIMLITIGATION_STATUS=="In litigation",1,0)
mas$Litigation_Ind[is.na(mas$Litigation_Ind)]=0

mas$Police_Notify_Ind=ifelse(mas$CLAIMPOLICENOTIFIED=="Yes",1,0)
mas$Fire_Notify_Ind=ifelse(mas$CLAIMFIRENOTIFIED=="Yes",1,0)

mas$SameDay_Report=ifelse(mas$Time_To_Report==0,1,0)
mas$NextDay_Report=ifelse(mas$Time_To_Report==1,1,0)
mas$Delayed_Report=ifelse(mas$Time_To_Report>1,1,0)

mas$Single_Role=ifelse(mas$P_Roles_Count==1,1,0)
mas$Roles_1_4=ifelse(mas$P_Roles_Count>1 & mas$P_Roles_Count<=4,1,0)
mas$Roles_4_8=ifelse(mas$P_Roles_Count>4 & mas$P_Roles_Count<=8,1,0)
mas$Many_Roles=ifelse(mas$P_Roles_Count>8,1,0)

mas$LTE_8_Roles=ifelse(mas$Many_Roles==1,0,1)

mas$RP_LTE_1k=ifelse(mas$Recover_Potential<=1000,1,0)
mas$RP_GT_1K_LTE_2k=ifelse(mas$Recover_Potential>1000 & mas$Recover_Potential<=2000,1,0)
mas$RP_GT_2k_LTE_3k=ifelse(mas$Recover_Potential>2000 & mas$Recover_Potential<=3000,1,0)
mas$RP_GT_3k_LTE_4k=ifelse(mas$Recover_Potential>3000 & mas$Recover_Potential<=4000,1,0)
mas$RP_GT_4k_LTE_5k=ifelse(mas$Recover_Potential>4000 & mas$Recover_Potential<=5000,1,0)
mas$RP_GT_5k=ifelse(mas$Recover_Potential>5000,1,0)

year=mas$Claim_Age/365
mas$ClaimAge_LTE_1Y=ifelse(year<=1,1,0)
mas$ClaimAge_GT_1Y_LTE_3Y=ifelse(year>1 & year<=3,1,0)


#Time_To P_Note - Sameday, NextDay, SameWeek, Delayed
mas$SameDay_PReport=ifelse(mas$Time_To_Pnote<1,1,0)
mas$NextDay_PReport=ifelse(mas$Time_To_Pnote>=1 & mas$Time_To_Pnote<2,1,0)
mas$SameWeek_PReport=ifelse(mas$Time_To_Pnote>=2 & mas$Time_To_Pnote<=7,1,0)
mas$Delayed_PReport=ifelse(mas$Time_To_Pnote>7,1,0)

mas$V_PT_TP4[is.na(mas$V_PT_TP4)]=0;
mas$V_PT_TP5[is.na(mas$V_PT_TP5)]=0;



mas$Multiple_Veh_Indicator=ifelse(mas$Multiple_Veh_Involved>1,1,0);


cat(paste("\n Done with the New Variables at",Sys.time()));

#########################GETTING ANALYSIS DATA - VERSION 1.0***

# Master Data Variables
cols=c("CLAIMID",
"POLICYTYPE",
"VEHICLEPARTY",
"QUOTEREPAIRAMOUNT",
"EXTRACTDATE",
"CLOSEDATE",
"CLAIMSTATUS",
"CLAIMDECISION",
"CLAIMLIABILITY",
"CLAIMLOSSDATE",
"CLAIMLODGEDATE",
"CLAIMLOSSCAUSE",
"CLAIMLOSSSUBCAUSE",
"CLAIMLITIGATION_STATUS",
"CLAIMPOLICENOTIFIED",
"CLAIMPOLICEDATE",
"CLAIMPOLICETIME",
"CLAIMFIRENOTIFIED",
"CLAIMEXCESSTOTAL",
"CLAIMEXCESSAPPLICABLE",
"V_PT_Insured",
"V_PT_TP1",
"V_PT_TP2",
"V_PT_TP3",
"V_PT_TP4",
"V_PT_TP5",
"V_LP_Insured",
"V_LP_Third.Party",
"P_ROLE_Agency.Agent",
"P_ROLE_Claimant",
"P_ROLE_Contact",
"P_ROLE_Defendant",
"P_ROLE_Driver",
"P_ROLE_Financier",
"P_ROLE_Insured",
"P_ROLE_Insurer",
"P_ROLE_Others",
"P_ROLE_Owner",
"P_ROLE_Payee",
"P_ROLE_Payer",
"P_ROLE_Repair.Shop",
"P_ROLE_Reporter",
"P_ROLE_Responsible",
"P_ROLE_Third.Party",
"P_ROLE_Witness",
"P_ROLE_Unknown",
"P_FATAL",
"P_INJURED",
"P_UNHURT",
"LT_Learner",
"LT_Open",
"LT_Provisional",
"LT_Unknown",
"P_TP1",
"P_TP2",
"P_TP3",
"P_TP4",
"P_TP5",
"P_TP6",
"P_TP7",
"P_TP8",
"P_TP9",
"P_Insured",
"Time_To_Report",
"Time_To_Pnote",
"Recover_Potential",
"RISKSUMINSURED",
"Y",
"Claim_Age",
"P_Male",
"P_Female",
"P_Unknown",
"Multiple_Veh_Involved",
"Alc_Drug_Ind",
"V_Damage_Ind",
"V_Tot_Loss_Ind",
"P_Roles_Count",
"V_LOSS_PARTY_Ind",
"P_LT_18",
"P_18_25",
"P_25_35",
"P_35_55",
"P_55_65",
"P_GT_65",
"D_LT_18",
"D_18_25",
"D_25_35",
"D_35_55",
"D_55_65",
"D_GT_65",
"Heavy_Vehicle",
"Small_Vehicle",
"Medium_Vehicle",
"Others",
"V_Age_LT_2",
"V_Age_2_15",
"V_Age_15_50",
"V_Age_GT_50",
"Vehicle_Age",
"Recovery_Indicator",
"Excess_Waived_Ind",
"C_LC_Damage",
"C_LC_Mechanical",
"C_LC_Natural",
"C_LC_Other",
"C_LC_Theft",
"Multiple_Veh_Indicator",
"RSI_LT_15K",
"RSI_15K_30K",
"RSI_GT_30K",
"QRA_LT_2K",
"QRA_2K_4K",
"QRA_GT_4K",
"CET_LT_6",
"CET_6_7",
"CET_GT_7",
"CEA_ET_0",
"CEA_0_600",
"CEA_GT_600",
"Litigation_Ind",
"Police_Notify_Ind",
"Fire_Notify_Ind", 
"SameDay_Report",
"NextDay_Report",
"Delayed_Report",
"Single_Role", 
"Roles_1_4",
"Roles_4_8",
"Many_Roles",
"RP_LTE_1k",
"RP_GT_1K_LTE_2k",
"RP_GT_2k_LTE_3k",
"RP_GT_3k_LTE_4k",
"RP_GT_4k_LTE_5k",
"RP_GT_5k",
"ClaimAge_LTE_1Y",
"ClaimAge_GT_1Y_LTE_3Y",
"SameDay_PReport",
"NextDay_PReport",
"SameWeek_PReport",
"Delayed_PReport");


colnames(mas)[118]="P_ROLE_Agency.Agent"
colnames(mas)[130]="P_ROLE_Repair.Shop"

Analysis_Data=subset(mas,select=cols);

Analysis_Data$ClaimAge_LTE_1Y=NULL;
Analysis_Data$ClaimAge_GT_1Y_LTE_3Y=NULL;

year=Analysis_Data$Claim_Age/365
Analysis_Data$Claim_Age_Ind=ifelse(year<=1,1,0)


cat("\nDone with A_Data creation");
# The analysis data has
# CLAIMDECISION=""
# # CLAIMLITIGATION_STATUS="" and NA	(by "")
# CLAIMPOLICEDATE=NA
# CLAIMPOLICETIME=""
# # CLAIMEXCESSAPPLICABLE=NA	(by 0)
# # Risk_Sum_Insured=NA	(by 0)
# # Vehicle_Age=NA	(by 0)
Analysis_Data$Vehicle_Age[is.na(Analysis_Data$Vehicle_Age)]=0;
Analysis_Data$CLAIMEXCESSAPPLICABLE[is.na(Analysis_Data$CLAIMEXCESSAPPLICABLE)]=0;
Analysis_Data$CLAIMLITIGATION_STATUS[is.na(Analysis_Data$CLAIMLITIGATION_STATUS)]="";
Analysis_Data$RISKSUMINSURED[is.na(Analysis_Data$RISKSUMINSURED)]=0;

######################	ALL THESE HAVE STANDARD DEVIATION OF ZERO (i.e All values are 0)
# Alc_Drug_Ind = NA
# P_TP9 = NA
# P_TP14 = NA
# P_TP20 = NA
# V_PT_TP8 = NA

# library(RODBC)
# odbc = odbcDriverConnect(connection="server=MYVIEWSOA01;database=Subrogation;trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;")       
# Analysis_Data$Vehicle_Age[is.na(Analysis_Data$Vehicle_Age)]=0;
# Analysis_Data$Risk_Sum_Insured[is.na(Analysis_Data$Risk_Sum_Insured)]=0;
# Analysis_Data$CLAIMEXCESSAPPLICABLE[is.na(Analysis_Data$CLAIMEXCESSAPPLICABLE)]=0;
# Analysis_Data$CLAIMLITIGATION_STATUS[is.na(Analysis_Data$CLAIMLITIGATION_STATUS)]="";


# Analysis_Data$EXTRACTDATE=as.Date(Analysis_Data$EXTRACTDATE,"%d%b%Y")
# Analysis_Data$EXTRACTDATE=paste(Analysis_Data$EXTRACTDATE,"00:00:00");
# Analysis_Data$EXTRACTDATE[substr(Analysis_Data$EXTRACTDATE,1,2)=="NA"]="";

# library(chron)
# ############CONVERT TIMES
# CLAIMPOLICETIME=chron(times=Analysis_Data$CLAIMPOLICETIME)
# CLAIMPOLICETIME[is.na(CLAIMPOLICETIME)]="00:00:00";

# Analysis_Data$CLOSEDATE=as.Date(Analysis_Data$CLOSEDATE,"%d%b%Y")
# Analysis_Data$CLOSEDATE=paste(Analysis_Data$CLOSEDATE,"00:00:00");
# Analysis_Data$CLAIMLOSSDATE=as.Date(Analysis_Data$CLAIMLOSSDATE,"%d%b%Y")
# Analysis_Data$CLAIMLOSSDATE=paste(Analysis_Data$CLAIMLOSSDATE,"00:00:00");
# Analysis_Data$CLAIMLODGEDATE=as.Date(Analysis_Data$CLAIMLODGEDATE,"%d%b%Y")
# Analysis_Data$CLAIMLODGEDATE=paste(Analysis_Data$CLAIMLODGEDATE,"00:00:00");
# Analysis_Data$CLAIMCLOSEDATE=as.Date(Analysis_Data$CLAIMCLOSEDATE,"%d%b%Y")
# Analysis_Data$CLAIMCLOSEDATE=paste(Analysis_Data$CLAIMCLOSEDATE,"00:00:00");
# Analysis_Data$CLAIMPOLICEDATE=as.Date(Analysis_Data$CLAIMPOLICEDATE,"%d-%b-%y") 
# Analysis_Data$CLAIMPOLICEDATE=paste(Analysis_Data$CLAIMPOLICEDATE,CLAIMPOLICETIME);


# Analysis_Data$CLOSEDATE[substr(Analysis_Data$CLOSEDATE,1,2)=="NA"]="";
# Analysis_Data$CLAIMLOSSDATE[substr(Analysis_Data$CLAIMLOSSDATE,1,2)=="NA"]="";
# Analysis_Data$CLAIMLODGEDATE[substr(Analysis_Data$CLAIMLODGEDATE,1,2)=="NA"]="";
# Analysis_Data$CLAIMCLOSEDATE[substr(Analysis_Data$CLAIMCLOSEDATE,1,2)=="NA"]="";
# Analysis_Data$CLAIMPOLICEDATE[substr(Analysis_Data$CLAIMPOLICEDATE,1,2)=="NA"]="";

# Analysis_Data[is.na(Analysis_Data)]="";


# sqlSave(odbc,Analysis_Data,"Analysis_Data_Version_5",safer=FALSE,append=TRUE)

colss=c("V_PT_Insured"     ,   "V_PT_TP1"      ,      "V_PT_TP2"           ,
"V_PT_TP3"       ,    "V_PT_TP4"          ,  "V_PT_TP5",           
"V_LP_Insured"       , "V_LP_Third.Party"   , "P_ROLE_Agency.Agent",
"P_ROLE_Claimant"    , "P_ROLE_Contact"      ,"P_ROLE_Defendant"   ,
"P_ROLE_Driver"      , "P_ROLE_Financier"    ,"P_ROLE_Insured"     ,
"P_ROLE_Insurer"     , "P_ROLE_Others"      , "P_ROLE_Owner"       ,
"P_ROLE_Payee"      ,  "P_ROLE_Payer"       , "P_ROLE_Repair.Shop" ,
"P_ROLE_Reporter"  ,   "P_ROLE_Responsible" , "P_ROLE_Third.Party" ,
"P_ROLE_Witness"  ,    "P_ROLE_Unknown"     , "P_FATAL"       ,     
"P_INJURED"           ,"P_UNHURT"           , "LT_Learner"        , 
"LT_Open"            , "LT_Provisional"     , "LT_Unknown"  ,       
"P_TP1"              , "P_TP2"              , "P_TP3"          ,    
"P_TP4"               ,"P_TP5"              , "P_TP6"  ,            
"P_TP7"               ,"P_TP8"              , "P_TP9"   ,           
"P_Insured" ,
"P_Male"   ,              "P_Female"            ,   "P_Unknown"            , 
"Alc_Drug_Ind"       ,    "V_Damage_Ind"          ,
"V_Tot_Loss_Ind"     ,     "V_LOSS_PARTY_Ind"      ,
"P_LT_18"                ,"P_18_25"          ,      "P_25_35"               ,
"P_35_55"          ,      "P_55_65"         ,       "P_GT_65"               ,
"D_LT_18"          ,      "D_18_25"        ,        "D_25_35"               ,
"D_35_55"           ,     "D_55_65"       ,         "D_GT_65"               ,
"Heavy_Vehicle"     ,     "Small_Vehicle",          "Medium_Vehicle"        ,
"Others"            ,     "V_Age_LT_2"  ,           "V_Age_2_15"            ,
"V_Age_15_50"       ,     "V_Age_GT_50",            "Vehicle_Age"           ,
"Recovery_Indicator",     "Excess_Waived_Ind"     , "C_LC_Damage"           ,
"C_LC_Mechanical"   ,     "C_LC_Natural"          , "C_LC_Other"            ,
"C_LC_Theft"        ,     "Multiple_Veh_Indicator", "RSI_LT_15K"            ,
"RSI_15K_30K"       ,     "RSI_GT_30K"           ,  "QRA_LT_2K"             ,
"QRA_2K_4K"          ,    "QRA_GT_4K"           ,   "CET_LT_6"              ,
"CET_6_7"             ,   "CET_GT_7"           ,    "CEA_ET_0"              ,
"CEA_0_600"          ,    "CEA_GT_600"         ,    "Litigation_Ind"        ,
"Police_Notify_Ind"  ,    "Fire_Notify_Ind"    ,    "SameDay_Report"        ,
"NextDay_Report"     ,    "Delayed_Report"    ,     "Single_Role"           ,
"Roles_1_4"          ,    "Roles_4_8"           ,   "Many_Roles"            ,
"RP_LTE_1k"           ,   "RP_GT_1K_LTE_2k"  ,      "RP_GT_2k_LTE_3k"       ,
"RP_GT_3k_LTE_4k"       , "RP_GT_4k_LTE_5k" ,       "RP_GT_5k"              ,
"SameDay_PReport"      ,  "NextDay_PReport",        "SameWeek_PReport"      ,
"Delayed_PReport"       , "Claim_Age_Ind")

Analysis_Data3=subset(Analysis_Data,select=colss);
for(i in 1:ncol(Analysis_Data3))
{
	Analysis_Data3[i]=ifelse(Analysis_Data3[i]==0,0,1)
}
colss2=setdiff(colnames(Analysis_Data),colss);
Analysis_Data4=subset(Analysis_Data,select=colss2);
Analysis_Data2=cbind(Analysis_Data4,Analysis_Data3)

Analysis_Data=Analysis_Data2;
rm(Analysis_Data2,Analysis_Data3,Analysis_Data4)


cat("\nDone with A_Data Mod");
######################################################################################################
###################################MODEL DEVELOPMENT##################################################
######################################################################################################
# Claim_Age_Ind
# P_GT_65
# P_Male
# P_Insured
# LT_Open
# Police_Notify_Ind
# SameDay_Report
# C_LC_Damage
# P_ROLE_.Third.Party
# Multiple_Veh_Indicator

cols=c('Claim_Age_Ind',
'P_GT_65',
'P_Male',
'P_Insured',
'LT_Open',
'Police_Notify_Ind',
'SameDay_Report',
'C_LC_Damage',
'P_ROLE_Third.Party',
'Multiple_Veh_Indicator'
)
set.seed(1234);
write.csv(Analysis_Data,"Test_Analysis_Data.csv",row.names=F)
Analysis_Data2=subset(Analysis_Data,select=c('Y',cols))
Logistic_Reg=glm(Y~.,data=Analysis_Data2,family=binomial("logit"))
Logistic_Output=predict(Logistic_Reg,newdata=Analysis_Data2,type="response")
Analysis_Data$Scores=Logistic_Output

Predict = data.frame(Predicted=Logistic_Output);

# library(ROCR)

# pred <- prediction(Predict$Predicted, Analysis_Data2$Y)
# perf <- performance(pred,"tpr","fpr")
# plot(perf, main="ROC curve", colorize=T)
# # Area Under the Curve
# auc.perf = performance(pred, measure = "auc")
# auc <- unlist(slot(auc.perf, "y.values"))
# text(x= 0.4, y= 0.4, labels=paste("AUC = ",as.character(auc)), xpd=TRUE,cex=0.7)
# TPR AND TNR, ACCURACY
Data=data.frame(Actual_Y=Analysis_Data2$Y,Score=Predict$Predicted)
Data$Predicted_Y=ifelse(Data$Score>=0.50,1,0)


cat(paste("\n Done with the Modelling at",Sys.time()));

#################### ACCURACY AND LIFT
library(caret)
Predicting = function(train,test)
{
	Logistic_Reg=glm(Y~.,data=train,family=binomial("logit"))
	Logistic_Output=predict(Logistic_Reg,newdata=test,type="response")
	Predict = data.frame(Predicted=Logistic_Output);
	Predict$Predicted=ifelse(Predict$Predicted>=0.5,1,0)
	Predict$Predicted=factor(Predict$Predicted)
	#cat(confusionMatrix(Predict$Predicted,test$Y))
	return(confusionMatrix(Predict$Predicted,test$Y))
}
Predict1=Predicting(Analysis_Data2,Analysis_Data2);
TP=Predict1$table[1]
FN=Predict1$table[2]
FP=Predict1$table[3]
TN=Predict1$table[4]
Data$TPR=TP/(TP+FN) #(SENSITIVITY)
Data$TNR=TN/(FP+TN) #(SPECIFICTY)
Data$FPR=FP/(FP+TN)   #(1-SPECIFICTY) (1-TNR)
Data$FNR=FN/(FN+TP)
Data$ACCURACY=(TP+TN)/(TP+FN+FP+TN)
df=head(Data[c(-1,-2,-3)],1)
write.csv(Data,"Accuracy.csv",row.names=F)
write.csv(df,"Accuracy2.csv",row.names=F)

Calc_Lift = function(Logistic_Output,test,name)
{
	
	Predict = data.frame(Predicted=Logistic_Output);
	Data=data.frame(Actual_Y=test$Y,Score=Predict$Predicted)
	library(dplyr)
	Data=Data[order(Data$Score),]
	Data$Decile=ntile(Data$Score,10)
	P_Min=numeric()
	P_Max=numeric()
	Total_1=integer()
	Total_0=integer()
	for(i in 1:10)
	{
		P_Min=c(P_Min,min(Data$Score[Data$Decile==i]))
		P_Max=c(P_Max,max(Data$Score[Data$Decile==i]))
		Total_0=c(Total_0,length(Data$Score[Data$Decile==i & Data$Actual_Y==0]))
		Total_1=c(Total_1,length(Data$Score[Data$Decile==i & Data$Actual_Y==1]))
	}
	Dev=data.frame(
					Rank=order(as.integer(names(table(Data$Decile)))),
					P_Min=P_Min,
					P_Max=P_Max,
					Total=Total_1+Total_0,
					Ones=Total_1,
					Zeroes=Total_0);
					
	Dev=Dev[order(Dev$Rank,decreasing=T),]
	Dev$Cumilative_Ones=cumsum(Dev$Ones)
	Dev$Cumilative_Zeroes=cumsum(Dev$Zeroes)
	Dev$Cumilative_Ones_Perc=Dev$Cumilative_Ones/sum(Dev$Ones)
	Dev$Cumilative_Zeroes_Perc=Dev$Cumilative_Zeroes/sum(Dev$Zeroes)
	Dev$KS=Dev$Cumilative_Ones_Perc-Dev$Cumilative_Zeroes_Perc;
	Dev$EVENT=(Dev$Ones/sum(Dev$Ones))
	Dev$GAIN=cumsum(Dev$EVENT)
	Dev$Total_Perc=(Dev$Total/sum(Dev$Total))
	Dev$Cumilative_Total_Perc=cumsum(Dev$Total_Perc)
	Dev$LIFT=Dev$GAIN/Dev$Cumilative_Total_Perc
	
	Dev$Cumilative_Ones_Perc=round(Dev$Cumilative_Ones_Perc*100)
	Dev$Cumilative_Zeroes_Perc=round(Dev$Cumilative_Zeroes_Perc*100)
	Dev$EVENT=round(Dev$EVENT*100)
	Dev$GAIN=round(Dev$GAIN*100)
	Dev$Total_Perc=round(Dev$Total_Perc*100)
	Dev$Cumilative_Total_Perc=round(Dev$Cumilative_Total_Perc*100)
	
	write.csv(Dev,name,row.names=F)
}
Calc_Lift(Logistic_Output,Analysis_Data2,"LIFT.csv");

cat(paste("\n Done with the Lift at",Sys.time()));

######### CREATE DECILES;
#Analysis_Data=Analysis_Data[order(Analysis_Data$Scores,decreasing=F),]
library(dplyr)
# Analysis_Data=Analysis_Data[order(Analysis_Data$Scores,decreasing=T),]
Analysis_Data$Decile=ntile(Analysis_Data$Scores,10)

cat(paste("\n Done with the Deciles at",Sys.time()));

######### CREATE PARTY AGE: 155:171
mas[, 155:171][is.na(mas[, 155:171])] = 0
mas2=mas[,155:171];
m=apply(mas2, 1, max);
mas$Party_Age=m; 
Analysis_Data$Party_Age=m;
# rm(mas);

set.seed(1234)
Analysis_Data$Split=runif(nrow(Analysis_Data))
Analysis_Data$SETTLED_AMOUNT=Analysis_Data$QUOTEREPAIRAMOUNT;
Analysis_Data$RECOVERY_AMOUNT=ifelse(Analysis_Data$Y==0,0,round(Analysis_Data$SETTLED_AMOUNT*Analysis_Data$Split,2))

Decile2=Analysis_Data[Analysis_Data$Y==1 & (Analysis_Data$Decile==1 | Analysis_Data$Decile==2 | Analysis_Data$Decile==3 | Analysis_Data$Decile==4),]

cat(paste("\n Done with the Decile Data at",Sys.time()));

######################################################################################################
####################################CLUSTERING OF DATA ###############################################
######################################################################################################
# # # Cluster Variables
# P_Insured
# LT_Open
# C_LC_Damage
# P_Male
# Claim_Age

Analysis_Data2=subset(Decile2,select=c('P_Insured','LT_Open','C_LC_Damage','P_Male','Claim_Age'))
Analysis_Data2$P_Insured=NULL;
df=scale(Analysis_Data2)
set.seed(1234);
fit.km=kmeans(df,4);
Decile2$cluster=fit.km$cluster;
Cluster_Data=Decile2;
Cluster_Data$Profile=ifelse(Cluster_Data$cluster==1,"Perpetuate",
							ifelse(Cluster_Data$cluster==2,"Status Quo",
							ifelse(Cluster_Data$cluster==3,"Pursue",
							"Hard Pursue")))
							

cat(paste("\n Done with the Clustering at",Sys.time()));

# # Claim Age - Already there

# Party Age -  Already there


# Gender - Recoded but not transformed variable, in both data	#Party
Analysis_Data$Gender=ifelse(Analysis_Data$P_Male==1 & Analysis_Data$P_Female==0 & Analysis_Data$P_Unknown==0,"Male",
							ifelse(Analysis_Data$P_Female==1 & Analysis_Data$P_Male==0 & Analysis_Data$P_Unknown==0,"Female",
							ifelse(Analysis_Data$P_Male==1 & Analysis_Data$P_Female==1 & Analysis_Data$P_Unknown==0,"Both",
							"Unknown")))
							
Cluster_Data$Gender=ifelse(Cluster_Data$P_Male==1 & Cluster_Data$P_Female==0 & Cluster_Data$P_Unknown==0,"Male",
							ifelse(Cluster_Data$P_Female==1 & Cluster_Data$P_Male==0 & Cluster_Data$P_Unknown==0,"Female",
							ifelse(Cluster_Data$P_Male==1 & Cluster_Data$P_Female==1 & Cluster_Data$P_Unknown==0,"Both",
							"Unknown")))

# Party Type - Recoded but not transformed variable, in both data	#Party
Analysis_Data$Party_Type=ifelse(Analysis_Data$P_Insured==1,"Insured","Third Party");
Cluster_Data$Party_Type=ifelse(Cluster_Data$P_Insured==1,"Insured","Third Party");

# License Type - Recoded but not transformed variable, in both data	#Party	
# insured,driver,owner-lt;
# Analysis_Data2=Analysis_Data[Analysis_Data$P_ROLE__Driver==1 | Analysis_Data$P_ROLE__Owner==1 | Analysis_Data$P_ROLE__Insured_Role==1,]
Analysis_Data$LT_Open=as.integer(Analysis_Data$LT_Open);
Analysis_Data$LT_Unknown=as.integer(Analysis_Data$LT_Unknown);
Analysis_Data$LT_Provisional=as.integer(Analysis_Data$LT_Provisional);
Analysis_Data$LT_Learner=as.integer(Analysis_Data$LT_Learner);
Analysis_Data$s=ifelse(Analysis_Data$P_ROLE_Driver==1 | Analysis_Data$P_ROLE_Owner==1 | Analysis_Data$P_ROLE_Insured==1,Analysis_Data$LT_Open+Analysis_Data$LT_Unknown+Analysis_Data$LT_Provisional+Analysis_Data$LT_Learner,0)

Analysis_Data$License_Type=ifelse(Analysis_Data$s==1,
		ifelse(Analysis_Data$LT_Open==1,"Open",
		ifelse(Analysis_Data$LT_Learner==1,"Learner",
		ifelse(Analysis_Data$LT_Provisional==1,"Provisional",
		"Unknown"))),"BLAH")
Analysis_Data$License_Type[Analysis_Data$License_Type=="BLAH"]=ifelse(Analysis_Data$s>1 | Analysis_Data$s==0,
																		ifelse(Analysis_Data$LT_Open==1,"Open",
																		ifelse(Analysis_Data$LT_Provisional==1,"Provisional",
																		ifelse(Analysis_Data$LT_Learner==1,"Learner",
																		"Unknown"))),Analysis_Data$License_Type)
		
Cluster_Data$LT_Open=as.integer(Cluster_Data$LT_Open);
Cluster_Data$LT_Unknown=as.integer(Cluster_Data$LT_Unknown);
Cluster_Data$LT_Provisional=as.integer(Cluster_Data$LT_Provisional);
Cluster_Data$LT_Learner=as.integer(Cluster_Data$LT_Learner);
Cluster_Data$s=ifelse(Cluster_Data$P_ROLE_Driver==1 | Cluster_Data$P_ROLE_Owner==1 | Cluster_Data$P_ROLE_Insured==1,Cluster_Data$LT_Open+Cluster_Data$LT_Unknown+Cluster_Data$LT_Provisional+Cluster_Data$LT_Learner,0)

Cluster_Data$s=ifelse(Cluster_Data$P_ROLE_Driver==1 | Cluster_Data$P_ROLE_Owner==1 | Cluster_Data$P_ROLE_Insured==1,Cluster_Data$LT_Open+Cluster_Data$LT_Unknown+Cluster_Data$LT_Provisional+Cluster_Data$LT_Learner,0)
Cluster_Data$License_Type=ifelse(Cluster_Data$s==1,
		ifelse(Cluster_Data$LT_Open==1,"Open",
		ifelse(Cluster_Data$LT_Learner==1,"Learner",
		ifelse(Cluster_Data$LT_Provisional==1,"Provisional",
		"Unknown"))),"BLAH")
Cluster_Data$License_Type[Cluster_Data$License_Type=="BLAH"]=ifelse(Cluster_Data$s>1 | Cluster_Data$s==0,
																		ifelse(Cluster_Data$LT_Open==1,"Open",
																		ifelse(Cluster_Data$LT_Provisional==1,"Provisional",
																		ifelse(Cluster_Data$LT_Learner==1,"Learner",
																		"Unknown"))),Cluster_Data$License_Type)
		
Cluster_Data$s=NULL;
Analysis_Data$s=NULL;	

# # Police Notification - Already there

# Loss Cause - Recoded but not transformed variable, in both data
Analysis_Data$Loss_Cause=ifelse(Analysis_Data$C_LC_Damage==1,"Damage",
										ifelse(Analysis_Data$C_LC_Mechanical==1,"Mechanical",
										ifelse(Analysis_Data$C_LC_Natural==1,"Natural",
										ifelse(Analysis_Data$C_LC_Other==1,"Other",
										"Theft"))))
										
Cluster_Data$Loss_Cause=ifelse(Cluster_Data$C_LC_Damage==1,"Damage",
										ifelse(Cluster_Data$C_LC_Mechanical==1,"Mechanical",
										ifelse(Cluster_Data$C_LC_Natural==1,"Natural",
										ifelse(Cluster_Data$C_LC_Other==1,"Other",
										"Theft"))))
									
# # Vehicle Involved - Already there

# Notification Time - Create for decile data
Analysis_Data$Notification_Time=ifelse(Analysis_Data$SameDay_Report==1,"Same Day",
										ifelse(Analysis_Data$NextDay_Report==1,"Next Day",
										"Delayed Report"))
										
# Third Party Involvement - Recoded but not transformed variable, for decile data	#Party
Analysis_Data$Third_Party_Involvement=ifelse(Analysis_Data$P_ROLE_Third.Party==1,"Yes","No");

cat(paste("\n Done with the Analysis_Data and Clustered_Data at",Sys.time()));

######################################################################################################
######################################################################################################
######################################################################################################
################# MISSED OPPORTUNITY ANALYSIS
Analysis_Data$MO_Amount=Analysis_Data$SETTLED_AMOUNT-Analysis_Data$RECOVERY_AMOUNT;
Analysis_Data$MO_Ind=ifelse(Analysis_Data$Y==1 & Analysis_Data$Loss_Cause!="Natural" & Analysis_Data$MO_Amount>20,1,0)
months=round(Analysis_Data$Claim_Age/30);
Analysis_Data$Tenure=ifelse(months<=12,"LTE 1 Year",
					ifelse(months>12 & months<=24,"1 to 2 Years",
					"GT 2 Years"))
					
Cluster_Data$MO_Amount=Cluster_Data$SETTLED_AMOUNT-Cluster_Data$RECOVERY_AMOUNT;
Cluster_Data$MO_Ind=ifelse(Cluster_Data$Y==1 & Cluster_Data$Loss_Cause!="Natural" & Cluster_Data$MO_Amount>20,1,0)
months=round(Cluster_Data$Claim_Age/30);
Cluster_Data$Tenure=ifelse(months<=12,"LTE 1 Year",
					ifelse(months>12 & months<=24,"1 to 2 Years",
					"GT 2 Years"))

cat(paste("\n Done with the Missed Opportunity Analysis at",Sys.time()));

cat(paste("\n Ended the Execution at",Sys.time()));	
sink();
setwd("E:\\MyViewsOperationalAnalytics\\Subrogation Solution\\Data Files\\Data For Visualization Team")	
Analysis_Data$Policy_Product_Type=mas$POLICYPRODUCTTYPE
	
write.csv(Cluster_Data,"Final_Clustered_Data.csv",row.names=F)
write.csv(Analysis_Data,"Final_Analysis_Data.csv",row.names=F)
write.csv(mas,"Final_Master_Data.csv",row.names=F)



######################################### MODEL OUTPUT !!




# # cols=c('Claim_Age_Ind',
# # 'P_GT_65',
# # 'P_Male',
# # 'P_Insured',
# # 'LT_Open',
# # 'Police_Notify_Ind',
# # 'SameDay_Report',
# # 'C_LC_Damage',
# # 'P_ROLE_Third.Party',
# # 'Multiple_Veh_Indicator'
# # )
# # set.seed(1234);
# # Analysis_Data2=subset(Analysis_Data,select=c('Y',cols))
# # Analysis_Data2 <- Analysis_Data2[sample.int(nrow(Analysis_Data2)),]
# # train=Analysis_Data2[1:(nrow(Analysis_Data2)*0.6),]	# Development Data or Training Data
# # test=Analysis_Data2[((nrow(Analysis_Data2)*0.6)+1):nrow(Analysis_Data2),]	# Validation Data or Testing Data


# # Logistic_Reg=glm(Y~.,data=train,family=binomial("logit"))
# # Logistic_Reg2=glm(Y~.,data=test,family=binomial("logit"))
# # Logistic_Output=predict(Logistic_Reg,newdata=test,type="response")

# # Predict = data.frame(Predicted=Logistic_Output);
# # library(caret)
# # Predict1=Predicting(train,test);
# # sink("Final_OP_Combo_1.txt")
# # cat("For Development Data\n")
# # Concordance(Logistic_Reg)
# # cat("For Validation Data\n")
# # Concordance(Logistic_Reg2)
# # sink();

# # sink("Final_OP_Combo_1.txt",append=T)
# # cat("For Development Data\n")
# # Logistic_Reg
# # summary(Logistic_Reg)
# # cat("For Validation Data\n")
# # Logistic_Reg2
# # summary(Logistic_Reg2)
# # sink();

# # sink("Final_OP_Combo_1.txt",append=T)
# # cat("For Development Data\n")
# # Predict1
# # sink();


# # # Calculate ROC Curve and Area Under the Curve
# # library(ROCR)

# # pred <- prediction(Predict$Predicted, test$Y)
# # perf <- performance(pred,"tpr","fpr")
# # plot(perf, main="ROC curve", colorize=T)
# # # Area Under the Curve
# # auc.perf = performance(pred, measure = "auc")
# # auc <- unlist(slot(auc.perf, "y.values"))
# # text(x= 0.4, y= 0.4, labels=paste("AOC = ",as.character(auc)), xpd=TRUE,cex=0.7)

# # # Calculate Hosmer Lemeshow Test (Decile Analysis)
# # library(ResourceSelection)
# # set.seed(43657)

# # Logistic_Reg=glm(Y~.,data=train,family=binomial)
# # Logistic_Reg2=glm(Y~.,data=test,family=binomial)

# # h1=hoslem.test(Logistic_Reg$y,fitted(Logistic_Reg),g=10)
# # h2=hoslem.test(Logistic_Reg2$y,fitted(Logistic_Reg2),g=10)

# # h1_data=cbind(h1$observed,h1$expected)
# # h2_data=cbind(h2$observed,h2$expected)
# # write.csv(h1_data,"Hl_DEV.csv")
# # write.csv(h2_data,"Hl_VALID.csv")
# Decile2=Analysis_Data[Analysis_Data$Y==1 & (Analysis_Data$Decile==1 | Analysis_Data$Decile==2 | Analysis_Data$Decile==3 | Analysis_Data$Decile==4),]

# Analysis_Data2=subset(Decile2,select=c('P_Insured','LT_Open','C_LC_Damage','P_Male','Claim_Age'))
# Analysis_Data2$P_Insured=NULL;
# # df=scale(Analysis_Data2)

# Kmeans =function(A_Data,n)
# {
	
	# # A_Data=A_Data[A_Data$Y==1,]
	# # A_Data=head(A_Data,nrow(A_Data)*.3)
	# # A_Data$Y=NULL;
	# df=scale(A_Data)
	# fit.km=kmeans(df,n)
	# #print(fit.km$size)
	# cluster=data.frame(Cluster=1:n,Size_of_Clusters=fit.km$size)
	# cluster$Percent=round((cluster$Size_of_Clusters/sum(cluster$Size_of_Clusters))*100)
	# cluster=cbind(cluster,fit.km$centers)
	# cluster=cbind(cluster,aggregate(A_Data, by=list(cluster=fit.km$cluster), mean))
	# cluster$cluster=NULL;
	
	# #write.csv(cluster,paste(as.character(length(cols2)),"_",as.character(n),"_Cluster.csv",sep=""),row.names=F)
	# # write.csv(fit.km$centers,paste(as.character(length(cols2)),"_Centers_of_Clusters.csv",sep=""),row.names=F)
	# # write.csv(aggregate(A_Data, by=list(cluster=fit.km$cluster), mean),paste(as.character(length(cols2)),"_Means_of_Clusters.csv",sep=""),row.names=F)
	# A_Data$Cluster=fit.km$cluster
	# # #write.csv(Analysis_Data2,"Analysis_Data_With_Cluster.csv",row.names=F)
	# return(cluster);
# }
# k=Kmeans(Analysis_Data2,4)
# vif_calc=function(Analysis_Data2)
# {
	# Linear_Model=lm(Y~.,data=Analysis_Data2);
	# df=data.frame(VIF=vif(Linear_Model))
	# return(df)
# }

# Concordance = function(GLM.binomial) 
# {
  # outcome_and_fitted_col = cbind(GLM.binomial$y, GLM.binomial$fitted.values)
  # # get a subset of outcomes where the event actually happened
  # ones = outcome_and_fitted_col[outcome_and_fitted_col[,1] == 1,]
  # # get a subset of outcomes where the event didn't actually happen
  # zeros = outcome_and_fitted_col[outcome_and_fitted_col[,1] == 0,]
  # # Equate the length of the event and non-event tables
  # if (length(ones[,1])>length(zeros[,1])) {ones = ones[1:length(zeros[,1]),]}
    # else {zeros = zeros[1:length(ones[,1]),]}
  # # Following will be c(ones_outcome, ones_fitted, zeros_outcome, zeros_fitted)
  # ones_and_zeros = data.frame(ones, zeros)
  # # initiate columns to store concordant, discordant, and tie pair evaluations
  # conc = rep(NA, length(ones_and_zeros[,1]))
  # disc = rep(NA, length(ones_and_zeros[,1]))
  # ties = rep(NA, length(ones_and_zeros[,1]))
  # for (i in 1:length(ones_and_zeros[,1])) {
    # # This tests for concordance
    # if (ones_and_zeros[i,2] > ones_and_zeros[i,4])
    # {conc[i] = 1
     # disc[i] = 0
     # ties[i] = 0}
    # # This tests for a tie
    # else if (ones_and_zeros[i,2] == ones_and_zeros[i,4])
    # {
      # conc[i] = 0
      # disc[i] = 0
      # ties[i] = 1
    # }
    # # This should catch discordant pairs.
    # else if (ones_and_zeros[i,2] < ones_and_zeros[i,4])
    # {
      # conc[i] = 0
      # disc[i] = 1
      # ties[i] = 0
    # }
  # }
  # # Here we save the various rates
  # conc_rate = mean(conc, na.rm=TRUE)
  # disc_rate = mean(disc, na.rm=TRUE)
  # tie_rate = mean(ties, na.rm=TRUE)
  # return(list(concordance=conc_rate, num_concordant=sum(conc), discordance=disc_rate, num_discordant=sum(disc), tie_rate=tie_rate,num_tied=sum(ties)))
  
# }

# Predict1=Predicting(Analysis_Data2,Analysis_Data2);
# sink("Final_OP_Combo_1.txt")
# cat("\nFor Development Data\n")
# Concordance(Logistic_Reg)
# sink();

# sink("Final_OP_Combo_1.txt",append=T)
# cat("\nFor Development Data\n")
# Logistic_Reg
# summary(Logistic_Reg)
# sink();

# sink("Final_OP_Combo_1.txt",append=T)
# cat("\nFor Development Data\n")
# Predict1
# sink();
# library(car)
# df=vif_calc(Analysis_Data2)

# # Calculate Hosmer Lemeshow Test (Decile Analysis)
# library(ResourceSelection)
# set.seed(43657)


# h1=hoslem.test(Logistic_Reg$y,fitted(Logistic_Reg),g=10)

# h1_data=cbind(h1$observed,h1$expected)
# write.csv(h1_data,"Hl_DEV.csv")

