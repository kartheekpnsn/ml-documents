# # Put your data in A_Data
A_Data = Your_DataFrame

# # Make your output column name as “Y”
colnames(A_Data)[which(colnames(A_Data) == “Your_Output_Column_Name”)] = “Y”

# # Classify the Greys or Suspicious as 0.5 and Frauds as 1 and Normals as 0
# A_Data$Y = as.numeric(as.character(A_Data$Y))

=> WRITE THE CODE HERE FOR THE ABOVE FORMAT (in the comment)

# # Greys classified
finalModelData = A_Data[A_Data$Y != 0.5, ]
greyData = A_Data[A_Data$Y == 0.5, ]
greyData$Y = NULL
finalModelData$Y = as.factor(finalModelData$Y)

# Random Forest
fit = applyRandomForest(dataFile = finalModelData, beta = 5, ntree = 100)
prob_scores = predict(fit$fit, greyData, type = "prob")
r_score = (prob_scores[, 2] * 0.65)/(prob_scores[, 1] * 0.35)
greyData$Y = 1
# Classify greys using the r-score
greyData$Y[r_score >= 1] = 1
greyData$Y[r_score < 1] = 0

# # Combine the data
finalData = rbind(finalModelData, greyData)