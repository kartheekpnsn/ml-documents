rm(list=ls())
setwd("D:\\kartheek\\Schrondinger")
df= read.csv("Dup_Pays.csv")
df = df[!is.na(df$Y),]
rownames(df)=1:nrow(df)
df$orig_Y = df$Y
pos = sample(rownames(df[df$Y==1,]),round(nrow(df[df$Y==1,])/2))
neg = sample(rownames(df[df$Y==0,]),round(nrow(df[df$Y==0,])*0.001))
df[pos,ncol(df)-1]=0.5
df[neg,ncol(df)-1]=0.5
orig_Y = df$orig_Y
df$orig_Y = NULL
A_Data = df



# # Necessary libraries
library(e1071) # Naive bayes
library(randomForest) # Random Forest
library(caret)

# # Necessary file imports
source("D:\\kartheek\\Schrondinger\\NewCodes\\Model_Build - RF.R")

# # Case - 1: Greys Neglected
finalModelData = A_Data[A_Data$Y != 0.5, ]
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))


# # Case - 2: Grey as Normals
finalModelData = A_Data
finalModelData$Y[finalModelData$Y==0.5] = 0
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))


# # Case - 3: Greys as Blacks
finalModelData = A_Data
finalModelData$Y[finalModelData$Y==0.5] = 1
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))


# # Case - 4: Greys classified
finalModelData = A_Data[A_Data$Y != 0.5, ]
greyData = A_Data[A_Data$Y == 0.5, ]
greyData$Y = NULL
finalModelData$Y = as.factor(finalModelData$Y)
# Naive Bayes
# ~ finalModel = naiveBayes(Y ~ ., data = finalModelData)
# ~ prob_scores = predict(finalModel, greyData, type = "raw")
# Random Forest
fit = applyRandomForest(dataFile = finalModelData, beta = 5, ntree = 100)
prob_scores = predict(fit$fit, greyData, type = "prob")
r_score = (prob_scores[, 2] * 0.65)/(prob_scores[, 1] * 0.35)
greyData$Y = 1
# Classify greys using the r-score
greyData$Y[r_score >= 1] = 1
greyData$Y[r_score < 1] = 0
# Mix the grey data with normals and frauds
finalModelData = rbind(finalModelData, greyData)
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))



# # # WhiteBlack model vs GreyModel on WhiteBlackData
finalModelData = A_Data[A_Data$Y != 0.5, ]
finalModelData$Y = as.factor(finalModelData$Y)
WhiteBlackData = finalModelData
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, WhiteBlackData, type = "prob")[,2] >= fit$cutoff), WhiteBlackData$Y))

finalModelData = A_Data[A_Data$Y != 0.5, ]
greyData = A_Data[A_Data$Y == 0.5, ]
greyData$Y = NULL
finalModelData$Y = as.factor(finalModelData$Y)
# Naive Bayes
# ~ finalModel = naiveBayes(Y ~ ., data = finalModelData)
# ~ prob_scores = predict(finalModel, greyData, type = "raw")
# Random Forest
fit = applyRandomForest(dataFile = finalModelData, beta = 5, ntree = 100)
prob_scores = predict(fit$fit, greyData, type = "prob")
r_score = (prob_scores[, 2] * 0.65)/(prob_scores[, 1] * 0.35)
greyData$Y = 1
# Classify greys using the r-score
greyData$Y[r_score >= 1] = 1
greyData$Y[r_score < 1] = 0
# Mix the grey data with normals and frauds
finalModelData = rbind(finalModelData, greyData)
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, WhiteBlackData, type = "prob")[,2] >= fit$cutoff), WhiteBlackData$Y))

