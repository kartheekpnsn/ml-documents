# # INSURANCE TEST
rm(list=ls())
setwd("D:\\kartheek\\SuncorpFinal")

Analysis_Data=read.csv("Model_Data_V3.csv",stringsAsFactor = F)

C1=read.csv("D:\\kartheek\\SuncorpFinal\\Claims Data\\motorclaim_training_1.csv", sep = "|")	#Motor_Claiming1d.csv
C2=read.csv("D:\\kartheek\\SuncorpFinal\\Claims Data\\motorclaim_training_2.csv", sep = "|")	#Motor_Claiming1d.csv
C3=read.csv("D:\\kartheek\\SuncorpFinal\\Claims Data\\motorclaim_training_3.csv", sep = "|")	#Motor_Claiming1d.csv
C4=read.csv("D:\\kartheek\\SuncorpFinal\\Claims Data\\motorclaim_training_4.csv", sep = "|")	#Motor_Claiming1d.csv

Claim=rbind(C1,C2,C3,C4)
rm(C1,C2,C3,C4)
Claim$Y=ifelse(Claim$Result_Type == "Fraud", 1, ifelse(Claim$Result_Type == "Suspected fraud", 0.5, 0))

Claim = subset(Claim, select = c("CLAIMID", "Y"))
colnames(Claim)[2] = "Y2"
library(plyr)
A_Data = join_all(list(Analysis_Data, Claim), by="CLAIMID", type="left")
original_Y = A_Data$Y
A_Data$Y = NULL
Analysis_Data_Z=A_Data[A_Data$C_LC_Theft==1 & A_Data$Y2==0,]
Analysis_Data_NZ=A_Data[(A_Data$Decline_Reasons=="Staged theft" | A_Data$Decline_Reasons == "Suspected staged theft") & A_Data$Y2!=0, ]
Analysis_Data=rbind(Analysis_Data_Z,Analysis_Data_NZ)
Analysis_Data2=subset(Analysis_Data,select=c(setdiff(colnames(Analysis_Data),"Y2"),"Y2"))
colnames(Analysis_Data2)[ncol(Analysis_Data2)] = "Y"
Analysis_Data2$Decline_Reasons=as.character(Analysis_Data2$Decline_Reasons)
Analysis_Data2$Decline_Reasons=NULL
Analysis_Data2$CLAIMLOSSCAUSE=NULL
Analysis_Data2$PrimaryKey=NULL
Analysis_Data2$TP_Gender=NULL
Analysis_Data2$TP_Alc_Drug_Ind=NULL
Analysis_Data2$TP_VehicleStyle=NULL
Analysis_Data2$LT_TP=NULL
Analysis_Data2$TP_DriverAge=NULL
Analysis_Data2$TP_VehicleAge=NULL
Analysis_Data2$TP=NULL
Analysis_Data2$AccidentProne_TP=NULL
Analysis_Data2$Insured_Vehicle_Drivable=NULL
Analysis_Data2$Insured_DriverAge=NULL;
Analysis_Data2$Time_To_Pnote[is.na(Analysis_Data2$Time_To_Pnote)]=5000
Analysis_Data2[is.na(Analysis_Data2)] = 0

chars = sapply(Analysis_Data2, is.character)
Only_Chars = Analysis_Data2[ , chars]
Only_Nums = Analysis_Data2[, !chars]
Only_Chars[Only_Chars=="0"] = "Unknown"
Only_Chars = data.frame(sapply(Only_Chars, as.factor))
A_Data = cbind(Only_Chars, Only_Nums)
A_Data$CLAIMID = NULL
rm(list = setdiff(ls(), c("A_Data", "original_Y")))




# # Necessary libraries
library(e1071) # Naive bayes
library(randomForest) # Random Forest
library(caret)

# # Necessary file imports
source("D:\\kartheek\\Schrondinger\\NewCodes\\Model_Build - RF.R")

# # Case - 1: Greys Neglected
finalModelData = A_Data[A_Data$Y != 0.5, ]
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))


# # Case - 2: Grey as Normals
finalModelData = A_Data
finalModelData$Y[finalModelData$Y==0.5] = 0
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))


# # Case - 3: Greys as Blacks
finalModelData = A_Data
finalModelData$Y[finalModelData$Y==0.5] = 1
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))


# # Case - 4: Greys classified
finalModelData = A_Data[A_Data$Y != 0.5, ]
greyData = A_Data[A_Data$Y == 0.5, ]
greyData$Y = NULL
finalModelData$Y = as.factor(finalModelData$Y)
# Naive Bayes
# ~ finalModel = naiveBayes(Y ~ ., data = finalModelData)
# ~ prob_scores = predict(finalModel, greyData, type = "raw")
# Random Forest
fit = applyRandomForest(dataFile = finalModelData, beta = 5, ntree = 100)
prob_scores = predict(fit$fit, greyData, type = "prob")
r_score = (prob_scores[, 2] * 0.65)/(prob_scores[, 1] * 0.35)
greyData$Y = 1
# Classify greys using the r-score
greyData$Y[r_score >= 1] = 1
greyData$Y[r_score < 1] = 0
# Mix the grey data with normals and frauds
finalModelData = rbind(finalModelData, greyData)
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))




# # # WhiteBlack model vs GreyModel on WhiteBlackData
finalModelData = A_Data[A_Data$Y != 0.5, ]
finalModelData$Y = as.factor(finalModelData$Y)
WhiteBlackData = finalModelData
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, WhiteBlackData, type = "prob")[,2] >= fit$cutoff), WhiteBlackData$Y))

finalModelData = A_Data[A_Data$Y != 0.5, ]
greyData = A_Data[A_Data$Y == 0.5, ]
greyData$Y = NULL
finalModelData$Y = as.factor(finalModelData$Y)
# Naive Bayes
# ~ finalModel = naiveBayes(Y ~ ., data = finalModelData)
# ~ prob_scores = predict(finalModel, greyData, type = "raw")
# Random Forest
fit = applyRandomForest(dataFile = finalModelData, beta = 5, ntree = 100)
prob_scores = predict(fit$fit, greyData, type = "prob")
r_score = (prob_scores[, 2] * 0.65)/(prob_scores[, 1] * 0.35)
greyData$Y = 1
# Classify greys using the r-score
greyData$Y[r_score >= 1] = 1
greyData$Y[r_score < 1] = 0
# Mix the grey data with normals and frauds
finalModelData = rbind(finalModelData, greyData)
finalModelData$Y = as.factor(finalModelData$Y)
# Train and Test sets
trainIndex1 = createDataPartition(finalModelData$Y, p = .60, list = FALSE, times = 1) #for balanced sampling
Train = finalModelData[trainIndex1,]
Test = finalModelData[-trainIndex1,]
# Naive bayes
# ~ finalModel = naiveBayes(Y ~ ., data = Train)
# ~ print(table(predict(finalModel, Test), Test$Y))
# Random Forest
fit = applyRandomForest(dataFile = Train, beta = 5, ntree = 100)
# ~ print(table(as.numeric(predict(fit$fit, Test, type = "prob")[,2] >= fit$cutoff), Test$Y))
calculatePRF(table(as.numeric(predict(fit$fit, WhiteBlackData, type = "prob")[,2] >= fit$cutoff), WhiteBlackData$Y))

