data = data.frame(A = sample(c('male', 'female', 'others'), 1000, replace = T), B = sample(c('normal', 'lean', 'fit', 'fat'), 1000, replace = T))
data$Y = 0
data$Y[data$A == 'male' & data$B %in% c('fat', 'lean', 'normal')] = 1
data$Y[data$A == 'female' & data$B %in% c('lean', 'fat')] = 1
data$Y[data$A == 'others' & data$B == 'lean'] = 1

test = data.frame(A = sample(c('male', 'female', 'others'), 100, replace = T), B = sample(c('normal', 'lean', 'fit', 'fat'), 100, replace = T))
test$Y = 0
test$Y[test$A == 'male' & test$B %in% c('fat', 'lean', 'normal')] = 1
test$Y[test$A == 'female' & test$B %in% c('lean', 'fat')] = 1
test$Y[test$A == 'others' & test$B == 'lean'] = 1

target = 'Y'
learning_rate = 1
rounds = 100
fit_list = list()
library(rpart)
library(randomForest)
base_model = randomForest(factor(Y) ~ ., data = data, ntree = 2, mtries = 1)
table(predict(base_model, data), data$Y)

y = data[, target]
# for class - 0
	y_pred = predict(base_model, data, type = 'prob')[, 1]

	for(i in 1:rounds){
		gradient = -(y - y_pred)
		m_data = cbind(subset(data, select = setdiff(colnames(data), target)), Y = gradient)
		fit = rpart(Y ~ ., data = m_data, control = rpart.control(minsplit = 2, maxdepth = 2))
		fit_list[[i]] = fit
		update = predict(fit, m_data)
		y_pred = y_pred - (learning_rate * update)
	}

	# predict
	y_pred = rep(0, nrow(test))
	for(tree in fit_list) {
		update = predict(tree, newdata = test)
		update = learning_rate * update
		y_pred = y_pred - update
	}
	class_0 = y_pred

# for class - 1
	y_pred = predict(base_model, data, type = 'prob')[, 2]

	for(i in 1:rounds) {
		gradient = -(y - y_pred)
		m_data = cbind(subset(data, select = setdiff(colnames(data), target)), Y = gradient)
		fit = rpart(Y ~ ., data = m_data, control = rpart.control(minsplit = 2, maxdepth = 2))
		fit_list[[i]] = fit
		update = predict(fit, m_data)
		y_pred = y_pred - (learning_rate * update)
	}

	# predict
	y_pred = rep(0, nrow(test))
	for(tree in fit_list) {
		update = predict(tree, newdata = test)
		update = learning_rate * update
		y_pred = y_pred - update
	}
	class_1 = y_pred

p_class_0 = 1 - (exp(class_0)/(exp(class_0) + exp(class_1)))
p_class_1 = 1 - (exp(class_1)/(exp(class_0) + exp(class_1)))
preds = cbind(actual = test$Y, data.frame(p_class_0, p_class_1))

# boosted model
performance(predicted = as.numeric(preds[, 3] > 0.45), original = preds[, 1])
# base model
performance(predicted = predict(base_model, test), original = preds[, 1])